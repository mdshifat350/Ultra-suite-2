// ==================== PART 3 (CONTINUATION) ====================
// part3.js এর ভাঙা `function customAppsView() {` থেকে শেষ পর্যন্ত মুছে এই পুরো ফাইল পেস্ট করুন

const $ = id => document.getElementById(id);

function customAppsView() {
    return `<div id="view-customapps" class="tab-content hidden space-y-6">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h2 class="text-2xl font-heading font-bold text-white flex items-center gap-2"><i class="fa-solid fa-globe text-cyan-400"></i>Custom Apps</h2>
            <button onclick="openAddAppModal()" class="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold"><i class="fa-solid fa-plus mr-1"></i>Add App</button>
        </div>
        <div id="customAppsGrid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"></div>
    </div>`;
}

function arcadeView() {
    return `<div id="view-arcade" class="tab-content hidden space-y-6">
        <div><h2 class="text-2xl font-heading font-bold text-white"><i class="fa-solid fa-gamepad text-amber-400 mr-2"></i>Arcade</h2><p class="text-slate-400 text-xs">Snake · Tic Tac Toe · Memory · Reaction</p></div>
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div class="glass-card p-5 rounded-2xl text-center space-y-3">
                <h3 class="font-bold text-white">🐍 Snake</h3>
                <canvas id="snakeCanvas" width="300" height="300" class="mx-auto rounded-xl bg-slate-950 border border-slate-800"></canvas>
                <p class="text-xs text-slate-300">Score: <span id="snakeScore">0</span></p>
                <div class="flex justify-center gap-2"><button onclick="snakeDir(-1,0)" class="w-10 h-10 rounded-lg bg-slate-800 text-white"><i class="fa-solid fa-arrow-left"></i></button><button onclick="snakeDir(0,-1)" class="w-10 h-10 rounded-lg bg-slate-800 text-white"><i class="fa-solid fa-arrow-up"></i></button><button onclick="snakeDir(0,1)" class="w-10 h-10 rounded-lg bg-slate-800 text-white"><i class="fa-solid fa-arrow-down"></i></button><button onclick="snakeDir(1,0)" class="w-10 h-10 rounded-lg bg-slate-800 text-white"><i class="fa-solid fa-arrow-right"></i></button></div>
                <button onclick="startSnake()" class="w-full py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold">Start</button>
            </div>
            <div class="glass-card p-5 rounded-2xl text-center space-y-3">
                <h3 class="font-bold text-white">⭕ Tic Tac Toe (You = X)</h3>
                <div id="tttBoard" class="grid grid-cols-3 gap-2 max-w-[240px] mx-auto"></div>
                <p class="text-sm text-slate-300" id="tttMsg">Your turn</p>
                <button onclick="newTTT()" class="w-full py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold">New Game</button>
            </div>
            <div class="glass-card p-5 rounded-2xl text-center space-y-3">
                <h3 class="font-bold text-white">🧠 Memory Match</h3>
                <div id="memBoard" class="grid grid-cols-4 gap-2 max-w-[280px] mx-auto"></div>
                <p class="text-xs text-slate-300">Moves: <span id="memMoves">0</span></p>
                <button onclick="newMemory()" class="w-full py-2 rounded-xl bg-purple-600 text-white text-xs font-bold">New Game</button>
            </div>
            <div class="glass-card p-5 rounded-2xl text-center space-y-3">
                <h3 class="font-bold text-white">⚡ Reaction Test</h3>
                <button id="reactBtn" onclick="reactClick()" class="w-full h-40 rounded-2xl bg-slate-800 text-white font-bold text-lg">Click to start</button>
                <p class="text-xs text-slate-300" id="reactMsg">Wait for green, then click!</p>
            </div>
        </div>
    </div>`;
}

function videoStudioView() {
    return `<div id="view-videostudio" class="tab-content hidden space-y-6">
        <div><h2 class="text-2xl font-heading font-bold text-white"><i class="fa-solid fa-film text-rose-400 mr-2"></i>Video Studio</h2><p class="text-slate-400 text-xs">Filters, speed & snapshot (ফাইল ডিভাইসেই থাকে)</p></div>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div class="lg:col-span-2 glass-card p-4 rounded-2xl space-y-3">
                <input type="file" id="videoFile" accept="video/*" onchange="loadVideo(event)" class="w-full text-xs text-slate-300">
                <video id="studioVideo" controls class="w-full rounded-xl bg-black max-h-[400px]"></video>
            </div>
            <div class="glass-card p-4 rounded-2xl space-y-3 text-xs text-slate-300">
                <div>Brightness <input type="range" id="vfBright" min="0" max="200" value="100" oninput="applyVideoFx()" class="w-full"></div>
                <div>Contrast <input type="range" id="vfContrast" min="0" max="200" value="100" oninput="applyVideoFx()" class="w-full"></div>
                <div>Saturation <input type="range" id="vfSat" min="0" max="300" value="100" oninput="applyVideoFx()" class="w-full"></div>
                <div>Grayscale <input type="range" id="vfGray" min="0" max="100" value="0" oninput="applyVideoFx()" class="w-full"></div>
                <div>Speed <select id="vfSpeed" onchange="applyVideoFx()" class="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1.5 text-white"><option>0.5</option><option selected>1</option><option>1.5</option><option>2</option></select></div>
                <button onclick="videoSnapshot()" class="w-full py-2 rounded-xl bg-rose-600 text-white font-bold"><i class="fa-solid fa-camera mr-1"></i>Snapshot</button>
            </div>
        </div>
    </div>`;
}

function designStudioView() {
    return `<div id="view-designstudio" class="tab-content hidden space-y-6">
        <div><h2 class="text-2xl font-heading font-bold text-white"><i class="fa-solid fa-paintbrush text-purple-400 mr-2"></i>Design Studio</h2></div>
        <div class="glass-card p-4 rounded-2xl space-y-3">
            <div class="flex flex-wrap gap-2 items-center">
                <input type="color" id="dsColor" value="#6366f1" class="w-10 h-10 rounded cursor-pointer">
                <input type="range" id="dsSize" min="1" max="40" value="5" class="w-32">
                <button onclick="dsEraser=false" class="px-3 py-2 rounded-lg bg-indigo-600 text-white text-xs font-bold"><i class="fa-solid fa-pen mr-1"></i>Brush</button>
                <button onclick="dsEraser=true" class="px-3 py-2 rounded-lg bg-slate-800 text-slate-200 text-xs font-bold"><i class="fa-solid fa-eraser mr-1"></i>Eraser</button>
                <button onclick="dsClear()" class="px-3 py-2 rounded-lg bg-red-600/30 text-red-300 text-xs font-bold">Clear</button>
                <button onclick="dsDownload()" class="px-3 py-2 rounded-lg bg-emerald-600 text-white text-xs font-bold"><i class="fa-solid fa-download mr-1"></i>PNG</button>
            </div>
            <canvas id="dsCanvas" width="800" height="450" class="w-full rounded-xl bg-white" style="touch-action:none"></canvas>
        </div>
    </div>`;
}

function developerView() {
    const box = 'w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono resize-none';
    return `<div id="view-developer" class="tab-content hidden space-y-6">
        <div><h2 class="text-2xl font-heading font-bold text-white"><i class="fa-solid fa-terminal text-emerald-400 mr-2"></i>Developer Tools</h2></div>
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div class="glass-card p-5 rounded-2xl space-y-3"><h3 class="font-bold text-white text-sm">URL Encode / Decode</h3>
                <textarea id="urlIn" rows="3" class="${box}"></textarea>
                <div class="flex gap-2"><button onclick="urlTool(true)" class="flex-1 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold">Encode</button><button onclick="urlTool(false)" class="flex-1 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold">Decode</button></div>
                <textarea id="urlOut" rows="3" readonly class="${box} text-emerald-300"></textarea></div>
            <div class="glass-card p-5 rounded-2xl space-y-3"><h3 class="font-bold text-white text-sm">Text Tools</h3>
                <textarea id="txtIn" rows="3" oninput="textStats()" class="${box}" placeholder="Type text..."></textarea>
                <p class="text-xs text-slate-300" id="txtStats">0 words · 0 chars</p>
                <div class="flex gap-2"><button onclick="caseTool('up')" class="flex-1 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold">UPPER</button><button onclick="caseTool('low')" class="flex-1 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold">lower</button><button onclick="caseTool('title')" class="flex-1 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold">Title</button></div></div>
            <div class="glass-card p-5 rounded-2xl space-y-3"><h3 class="font-bold text-white text-sm">Timestamp</h3>
                <input type="text" id="tsIn" placeholder="Unix seconds (blank = now)" class="${box}">
                <button onclick="tsTool()" class="w-full py-2 rounded-xl bg-purple-600 text-white text-xs font-bold">Convert</button>
                <p class="text-xs text-cyan-300 font-mono break-all" id="tsOut">-</p></div>
            <div class="glass-card p-5 rounded-2xl space-y-3"><h3 class="font-bold text-white text-sm">HEX → RGB</h3>
                <input type="text" id="hexIn" placeholder="#6366f1" oninput="hexTool()" class="${box}">
                <div class="flex items-center gap-3"><div id="hexSwatch" class="w-12 h-12 rounded-lg bg-slate-800"></div><p class="text-xs text-cyan-300 font-mono" id="hexOut">-</p></div></div>
        </div>
    </div>`;
}

function trackerView() {
    return `<div id="view-tracker" class="tab-content hidden space-y-6">
        <div><h2 class="text-2xl font-heading font-bold text-white"><i class="fa-solid fa-square-check text-teal-400 mr-2"></i>Todo List</h2><p class="text-slate-400 text-xs" id="todoCount">0 tasks</p></div>
        <div class="glass-card p-5 rounded-2xl flex gap-2">
            <input type="text" id="todoInput" placeholder="New task..." onkeydown="if(event.key==='Enter')addTodo()" class="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white">
            <button onclick="addTodo()" class="px-4 py-2 rounded-xl bg-teal-600 text-white text-xs font-bold"><i class="fa-solid fa-plus"></i></button>
        </div>
        <div id="todoList" class="space-y-2"></div>
    </div>`;
}

// ==================== INIT ====================
function initializeViews() {
    updateClock(); renderAlarms(); renderNotesList(); updateNotifBadge(); updateMessagesBadge();
    updateConverterUnits(); generatePalette(); newQuote(); renderTransactions(); updateWaterUI();
    renderHabits(); renderCalendar(); new2048(); newSudoku(); renderTodos(); renderCustomApps();
    newTTT(); newMemory(); drawSnake(); dsInit(); loadEditorTemplate(); updateTimerDisplay();
    const n = $('welcomeUserName');
    if (n && currentUser) n.textContent = currentUser.displayName || currentUser.username;
    if (siteSettings.announcement && $('announcementDisplay')) {
        $('announcementDisplay').classList.remove('hidden');
        $('announcementText').textContent = siteSettings.announcement;
    }
    const q = $('quickCodeInput'); if (q) q.addEventListener('input', () => { if (autoRun) runQuickCode(); });
    const mr = $('metronomeRange'); if (mr) mr.addEventListener('change', () => { if (metroTimer) startMetronome(); });
}

// cross-tab sync for chat
window.addEventListener('storage', e => {
    if (!currentUser) return;
    if (e.key === 'ultra_messages') { messagesDB = JSON.parse(e.newValue) || {}; updateMessagesBadge(); if ($('usersList')) renderUsers(); if (selectedChatUser) renderChatMessages(); }
    if (e.key === 'ultra_users') { usersDB = JSON.parse(e.newValue) || []; }
});

// ==================== UTILS ====================
function copyToClipboard(text) {
    const done = () => showToast('📋 Copied!', 'success');
    if (navigator.clipboard) navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
    else fallbackCopy(text, done);
}
function fallbackCopy(text, cb) {
    const t = document.createElement('textarea'); t.value = text; document.body.appendChild(t); t.select();
    try { document.execCommand('copy'); cb(); } catch (e) {} t.remove();
}
function audioCtx() { return new (window.AudioContext || window.webkitAudioContext)(); }

// ==================== LIVE EDITOR ====================
function runQuickCode() { const f = $('quickPreviewFrame'); if (f) f.srcdoc = $('quickCodeInput').value; }
function toggleAutoRun() { autoRun = !autoRun; $('autoRunBtn').innerHTML = `<i class="fa-solid fa-bolt mr-1"></i>Auto: ${autoRun ? 'ON' : 'OFF'}`; if (autoRun) runQuickCode(); }
function loadEditorTemplate() {
    $('quickCodeInput').value = `<!DOCTYPE html>
<html>
<head><style>
body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:linear-gradient(135deg,#6366f1,#ec4899);color:#fff}
button{padding:12px 24px;border:0;border-radius:12px;font-size:16px;cursor:pointer}
</style></head>
<body><div style="text-align:center"><h1 id="t">Hello!</h1><button onclick="t.textContent='Clicked 🎉'">Click me</button></div></body>
</html>`;
    runQuickCode();
}
function clearQuickCode() { $('quickCodeInput').value = ''; runQuickCode(); }

// ==================== POMODORO ====================
function startPomodoro() {
    if (pomodoroInterval) { clearInterval(pomodoroInterval); pomodoroInterval = null; return; }
    pomodoroInterval = setInterval(() => {
        pomodoroSeconds--;
        if (pomodoroSeconds <= 0) {
            playSound('alarm'); setTimeout(() => playSound('alarm'), 300);
            if (pomodoroMode === 'focus') { pomodoroSessions++; pomodoroMode = 'break'; pomodoroSeconds = 5 * 60; showToast('☕ Break time!', 'success'); }
            else { pomodoroMode = 'focus'; pomodoroSeconds = 25 * 60; showToast('🔥 Focus time!', 'success'); }
        }
        updatePomodoroUI();
    }, 1000);
}
function resetPomodoro() { clearInterval(pomodoroInterval); pomodoroInterval = null; pomodoroMode = 'focus'; pomodoroSeconds = 25 * 60; updatePomodoroUI(); }
function updatePomodoroUI() {
    const total = pomodoroMode === 'focus' ? 25 * 60 : 5 * 60;
    $('pomoDisplay').textContent = String(Math.floor(pomodoroSeconds / 60)).padStart(2, '0') + ':' + String(pomodoroSeconds % 60).padStart(2, '0');
    $('pomoMode').textContent = pomodoroMode === 'focus' ? 'Focus Time' : 'Break Time';
    $('pomoSessions').textContent = pomodoroSessions;
    $('pomoCircle').style.strokeDashoffset = 283 * (1 - pomodoroSeconds / total);
}

// ==================== QR ====================
function generateQR() {
    const text = $('qrContent').value.trim();
    if (!text) return showToast('টেক্সট দিন', 'error');
    const size = $('qrSize').value, color = $('qrColor').value.replace('#', '');
    const url = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&color=${color}&data=${encodeURIComponent(text)}`;
    $('qrOutput').innerHTML = `<img id="qrImg" src="${url}" alt="QR" class="mx-auto rounded-xl bg-white p-2" style="max-width:100%">`;
    window._qrUrl = url;
}
function downloadQR() {
    if (!window._qrUrl) return showToast('আগে QR বানান', 'error');
    fetch(window._qrUrl).then(r => r.blob()).then(b => {
        const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'qrcode.png'; a.click();
    }).catch(() => window.open(window._qrUrl, '_blank'));
}

// ==================== COLORS / GRADIENT ====================
function generatePalette() {
    const out = $('paletteOutput'); if (!out) return;
    out.innerHTML = Array.from({ length: 5 }, () => {
        const c = '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
        return `<div onclick="copyToClipboard('${c}')" class="cursor-pointer rounded-xl overflow-hidden border border-slate-800"><div class="h-24" style="background:${c}"></div><p class="text-center text-xs font-mono py-2 text-slate-200">${c}</p></div>`;
    }).join('');
}
function updateGradient() {
    const a = $('grad1').value, b = $('grad2').value, d = $('gradDir').value;
    $('gradientPreview').style.background = `linear-gradient(${d},${a},${b})`;
    $('gradCode').textContent = `background: linear-gradient(${d}, ${a}, ${b});`;
}
function copyGradient() { copyToClipboard($('gradCode').textContent); }

// ==================== CONVERTER ====================
const UNITS = {
    length: { m: 1, km: 1000, cm: 0.01, mm: 0.001, mile: 1609.344, yard: 0.9144, foot: 0.3048, inch: 0.0254 },
    weight: { kg: 1, g: 0.001, mg: 1e-6, lb: 0.453592, oz: 0.0283495, ton: 1000 },
    temperature: { C: 1, F: 1, K: 1 },
    area: { 'm²': 1, 'km²': 1e6, 'cm²': 1e-4, hectare: 1e4, acre: 4046.86, 'ft²': 0.092903 },
    volume: { L: 1, mL: 0.001, 'm³': 1000, gallon: 3.78541, cup: 0.236588 },
    speed: { 'm/s': 1, 'km/h': 0.277778, mph: 0.44704, knot: 0.514444 },
    time: { sec: 1, min: 60, hour: 3600, day: 86400, week: 604800 },
    data: { B: 1, KB: 1024, MB: 1048576, GB: 1073741824, TB: 1099511627776 }
};
function updateConverterUnits() {
    const cat = $('convCategory').value, opts = Object.keys(UNITS[cat]).map(u => `<option>${u}</option>`).join('');
    $('convFrom').innerHTML = opts; $('convTo').innerHTML = opts;
    $('convTo').selectedIndex = Math.min(1, Object.keys(UNITS[cat]).length - 1);
    convertUnits();
}
function convertUnits() {
    const cat = $('convCategory').value, v = parseFloat($('convInput').value), f = $('convFrom').value, t = $('convTo').value;
    if (isNaN(v)) { $('convResult').textContent = '0'; return; }
    let r;
    if (cat === 'temperature') {
        let c = f === 'C' ? v : f === 'F' ? (v - 32) * 5 / 9 : v - 273.15;
        r = t === 'C' ? c : t === 'F' ? c * 9 / 5 + 32 : c + 273.15;
    } else r = v * UNITS[cat][f] / UNITS[cat][t];
    $('convResult').textContent = (+r.toPrecision(10)).toString();
}

// ==================== CALCULATOR ====================
let calcExpr = '';
function calcNum(t) {
    const d = $('calcDisplay');
    if (t === 'C') { calcExpr = ''; d.value = '0'; return; }
    if (t === '=') {
        try {
            const e = calcExpr.replace(/÷/g, '/').replace(/×/g, '*').replace(/−/g, '-');
            if (!/^[0-9+\-*/.() ]+$/.test(e)) throw 0;
            const r = Function('"use strict";return (' + e + ')')();
            if (!isFinite(r)) throw 0;
            calcExpr = String(+r.toPrecision(12)); d.value = calcExpr;
        } catch (x) { d.value = 'Error'; calcExpr = ''; }
        return;
    }
    calcExpr += t; d.value = calcExpr;
}
function calcFunc(f) {
    const d = $('calcDisplay'); const v = parseFloat(d.value);
    if (isNaN(v)) return;
    const rad = v * Math.PI / 180;
    let r = f === 'sin' ? Math.sin(rad) : f === 'cos' ? Math.cos(rad) : f === 'tan' ? Math.tan(rad) : Math.sqrt(v);
    calcExpr = String(+r.toPrecision(10)); d.value = calcExpr;
}

// ==================== AGE / BMI / LOAN ====================
function calculateAge() {
    const b = new Date($('birthDate').value); if (isNaN(b)) return;
    const n = new Date();
    let y = n.getFullYear() - b.getFullYear();
    if (n < new Date(n.getFullYear(), b.getMonth(), b.getDate())) y--;
    const ms = n - b;
    $('ageYears').textContent = y;
    $('ageMonths').textContent = Math.floor(ms / (30.4375 * 864e5)).toLocaleString();
    $('ageDays').textContent = Math.floor(ms / 864e5).toLocaleString();
    $('ageHours').textContent = Math.floor(ms / 36e5).toLocaleString();
    $('ageResult').classList.remove('hidden');
}
function calculateBMI() {
    const w = parseFloat($('bmiWeight').value), h = parseFloat($('bmiHeight').value) / 100;
    if (!w || !h) return showToast('সঠিক মান দিন', 'error');
    const bmi = w / (h * h);
    const [cat, col] = bmi < 18.5 ? ['Underweight', 'text-sky-300'] : bmi < 25 ? ['Normal ✅', 'text-emerald-300'] : bmi < 30 ? ['Overweight', 'text-amber-300'] : ['Obese', 'text-red-300'];
    $('bmiValue').textContent = bmi.toFixed(1);
    $('bmiCategory').textContent = cat; $('bmiCategory').className = 'text-sm mt-2 font-bold ' + col;
    $('bmiResult').classList.remove('hidden');
}
function calculateLoan() {
    const P = parseFloat($('loanAmount').value), n = parseInt($('loanMonths').value), r = parseFloat($('loanRate').value) / 1200;
    if (!P || !n || isNaN(r)) return showToast('সব ঘর পূরণ করুন', 'error');
    const emi = r === 0 ? P / n : P * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
    const fmt = x => CURRENCY + Math.round(x).toLocaleString();
    $('loanMonthly').textContent = fmt(emi); $('loanTotal').textContent = fmt(emi * n); $('loanInterest').textContent = fmt(emi * n - P);
    $('loanResult').classList.remove('hidden');
}

// ==================== EXPENSE ====================
function addTransaction() {
    const type = $('expType').value, desc = $('expDesc').value.trim(), amt = parseFloat($('expAmount').value);
    if (!desc || !amt || amt <= 0) return showToast('বিবরণ ও সঠিক পরিমাণ দিন', 'error');
    transactions.unshift({ id: Date.now().toString(), type, desc, amt, date: new Date().toLocaleDateString() });
    saveTransactions(); $('expDesc').value = ''; $('expAmount').value = ''; renderTransactions();
}
function deleteTransaction(id) { transactions = transactions.filter(t => t.id !== id); saveTransactions(); renderTransactions(); }
function clearTransactions() { if (!confirm('সব transaction মুছবেন?')) return; transactions = []; saveTransactions(); renderTransactions(); }
function renderTransactions() {
    const inc = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amt, 0);
    const exp = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amt, 0);
    $('totalIncome').textContent = inc.toLocaleString(); $('totalExpense').textContent = exp.toLocaleString();
    $('totalBalance').textContent = (inc - exp).toLocaleString(); $('totalTransactions').textContent = transactions.length;
    $('transactionsList').innerHTML = transactions.map(t => `
        <div class="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <div><p class="text-xs font-semibold text-white">${escapeHtml(t.desc)}</p><p class="text-[10px] text-slate-500">${t.date}</p></div>
            <div class="flex items-center gap-3"><span class="text-sm font-bold ${t.type === 'income' ? 'text-emerald-400' : 'text-red-400'}">${t.type === 'income' ? '+' : '-'}${CURRENCY}${t.amt.toLocaleString()}</span>
            <button onclick="deleteTransaction('${t.id}')" class="text-slate-500 hover:text-red-400 text-xs"><i class="fa-solid fa-trash"></i></button></div>
        </div>`).join('') || '<p class="text-xs text-slate-500 text-center py-4">No transactions</p>';
}

// ==================== WATER ====================
function addWater(n) {
    waterCount = Math.max(0, waterCount + n);
    localStorage.setItem('ultra_water_' + new Date().toDateString(), waterCount); updateWaterUI();
    if (waterCount === 8 && n > 0) showToast('💧 Daily goal reached!', 'success');
}
function resetWater() { waterCount = 0; localStorage.setItem('ultra_water_' + new Date().toDateString(), 0); updateWaterUI(); }
function updateWaterUI() {
    $('waterGlasses').textContent = waterCount;
    $('waterCircle').style.strokeDashoffset = 283 * (1 - Math.min(waterCount / 8, 1));
}

// ==================== HABITS ====================
function addHabit() {
    const v = $('habitInput').value.trim(); if (!v) return;
    habits.push({ id: Date.now().toString(), name: v, days: {} });
    saveHabits(); $('habitInput').value = ''; renderHabits();
}
function toggleHabit(id) {
    const h = habits.find(x => x.id === id), k = new Date().toDateString();
    if (h.days[k]) delete h.days[k]; else h.days[k] = true;
    saveHabits(); renderHabits();
}
function deleteHabit(id) { habits = habits.filter(h => h.id !== id); saveHabits(); renderHabits(); }
function habitStreak(h) {
    let s = 0; const d = new Date();
    if (!h.days[d.toDateString()]) d.setDate(d.getDate() - 1);
    while (h.days[d.toDateString()]) { s++; d.setDate(d.getDate() - 1); }
    return s;
}
function renderHabits() {
    const l = $('habitsList'); if (!l) return;
    const k = new Date().toDateString();
    l.innerHTML = habits.map(h => `
        <div class="glass-card p-4 rounded-2xl flex items-center justify-between">
            <div class="flex items-center gap-3">
                <button onclick="toggleHabit('${h.id}')" class="w-8 h-8 rounded-full border-2 ${h.days[k] ? 'bg-emerald-500 border-emerald-500' : 'border-slate-600'} flex items-center justify-center text-white text-xs">${h.days[k] ? '<i class="fa-solid fa-check"></i>' : ''}</button>
                <div><p class="text-sm font-semibold text-white">${escapeHtml(h.name)}</p><p class="text-[10px] text-orange-300">🔥 ${habitStreak(h)} day streak</p></div>
            </div>
            <button onclick="deleteHabit('${h.id}')" class="text-slate-500 hover:text-red-400 text-xs"><i class="fa-solid fa-trash"></i></button>
        </div>`).join('') || '<p class="text-xs text-slate-500 text-center py-4">কোনো habit নেই</p>';
}

// ==================== CALENDAR ====================
function changeMonth(n) { calendarDate.setMonth(calendarDate.getMonth() + n); renderCalendar(); }
function renderCalendar() {
    const g = $('calendarGrid'); if (!g) return;
    const y = calendarDate.getFullYear(), m = calendarDate.getMonth();
    $('calendarTitle').textContent = calendarDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    const first = new Date(y, m, 1).getDay(), days = new Date(y, m + 1, 0).getDate(), t = new Date();
    let h = '';
    for (let i = 0; i < first; i++) h += '<div></div>';
    for (let d = 1; d <= days; d++) {
        const today = d === t.getDate() && m === t.getMonth() && y === t.getFullYear();
        h += `<div class="py-3 text-center text-sm rounded-lg ${today ? 'bg-indigo-600 text-white font-bold' : 'text-slate-300 hover:bg-slate-800'}">${d}</div>`;
    }
    g.innerHTML = h;
}

// ==================== QUOTES / DICE / RANDOM ====================
const QUOTES = [
    ['The only way to do great work is to love what you do.', 'Steve Jobs'], ['Stay hungry, stay foolish.', 'Steve Jobs'],
    ['Whether you think you can or you think you can’t, you’re right.', 'Henry Ford'], ['It always seems impossible until it’s done.', 'Nelson Mandela'],
    ['Well done is better than well said.', 'Benjamin Franklin'], ['The best way to predict the future is to create it.', 'Peter Drucker'],
    ['Do what you can, with what you have, where you are.', 'Theodore Roosevelt'], ['Dream big and dare to fail.', 'Norman Vaughan'],
    ['আমি পারব — এই বিশ্বাসই অর্ধেক জয়।', 'অজানা'], ['ছোট ছোট পদক্ষেপই বড় যাত্রার শুরু।', 'অজানা']
];
function newQuote() {
    const q = QUOTES[Math.floor(Math.random() * QUOTES.length)];
    $('quoteText').textContent = `"${q[0]}"`; $('quoteAuthor').textContent = '— ' + q[1];
}
function rollDice() {
    const faces = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'], el = $('diceOutput'); let i = 0;
    const t = setInterval(() => { el.textContent = faces[Math.floor(Math.random() * 6)]; if (++i > 8) { clearInterval(t); playSound('click'); } }, 60);
}
function flipCoin() { $('coinOutput').textContent = Math.random() < 0.5 ? '👑' : '🦅'; playSound('click'); }
function generateRandom() {
    const a = parseInt($('randomMin').value), b = parseInt($('randomMax').value);
    if (isNaN(a) || isNaN(b) || a > b) return showToast('সঠিক range দিন', 'error');
    $('randomResult').textContent = Math.floor(Math.random() * (b - a + 1)) + a;
}
function generatePassword() {
    const c = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*';
    const arr = new Uint32Array(16); crypto.getRandomValues(arr);
    $('randomPass').value = Array.from(arr, n => c[n % c.length]).join('');
}

// ==================== JSON / BASE64 / UUID / MARKDOWN ====================
function formatJSON() { try { $('jsonOutput').textContent = JSON.stringify(JSON.parse($('jsonInput').value), null, 2); } catch (e) { $('jsonOutput').textContent = '❌ Invalid JSON: ' + e.message; } }
function minifyJSON() { try { $('jsonOutput').textContent = JSON.stringify(JSON.parse($('jsonInput').value)); } catch (e) { $('jsonOutput').textContent = '❌ Invalid JSON: ' + e.message; } }
function encodeBase64() {
    try { $('base64Output').value = btoa(String.fromCharCode(...new TextEncoder().encode($('base64Input').value))); } catch (e) { $('base64Output').value = '❌ Error'; }
}
function decodeBase64() {
    try { $('base64Output').value = new TextDecoder().decode(Uint8Array.from(atob($('base64Input').value.trim()), c => c.charCodeAt(0))); } catch (e) { $('base64Output').value = '❌ Invalid Base64'; }
}
function generateUUIDs() {
    const n = Math.min(50, Math.max(1, parseInt($('uuidCount').value) || 1));
    $('uuidOutput').innerHTML = Array.from({ length: n }, () => {
        const u = crypto.randomUUID ? crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); });
        return `<div onclick="copyToClipboard('${u}')" class="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-purple-300 cursor-pointer hover:border-purple-500/50">${u}</div>`;
    }).join('');
}
function renderMarkdown() {
    let t = escapeHtml($('mdInput').value);
    t = t.replace(/```([\s\S]*?)```/g, '<pre class="bg-slate-950 p-3 rounded-lg text-xs overflow-x-auto"><code>$1</code></pre>')
        .replace(/^### (.*)$/gm, '<h3 class="text-base font-bold text-white mt-3">$1</h3>')
        .replace(/^## (.*)$/gm, '<h2 class="text-lg font-bold text-white mt-3">$1</h2>')
        .replace(/^# (.*)$/gm, '<h1 class="text-xl font-extrabold text-white mt-3">$1</h1>')
        .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\*(.+?)\*/g, '<i>$1</i>')
        .replace(/`([^`]+)`/g, '<code class="bg-slate-800 px-1 rounded text-pink-300">$1</code>')
        .replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener" class="text-indigo-400 underline">$1</a>')
        .replace(/^- (.*)$/gm, '<li class="ml-5 list-disc">$1</li>').replace(/\n/g, '<br>');
    $('mdOutput').innerHTML = t;
}

// ==================== PIANO / DRUM / METRONOME ====================
function playNote(freq) {
    if (!soundEnabled) return;
    try {
        const c = audioCtx(), o = c.createOscillator(), g = c.createGain();
        o.type = 'triangle'; o.frequency.value = freq; o.connect(g); g.connect(c.destination);
        g.gain.setValueAtTime(0.3, c.currentTime); g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 1);
        o.start(); o.stop(c.currentTime + 1); setTimeout(() => c.close(), 1200);
    } catch (e) {}
}
function playDrum(i) {
    if (!soundEnabled) return;
    const cfg = [[120, 'sine', 0.3], [440, 'triangle', 0.2], [880, 'sine', 0.5], [600, 'sawtooth', 0.25], [196, 'sawtooth', 0.4], [330, 'square', 0.3], [90, 'sine', 0.4], [1200, 'triangle', 0.15]][i];
    try {
        const c = audioCtx(), o = c.createOscillator(), g = c.createGain();
        o.type = cfg[1]; o.frequency.setValueAtTime(cfg[0], c.currentTime);
        o.frequency.exponentialRampToValueAtTime(Math.max(cfg[0] / 2, 30), c.currentTime + cfg[2]);
        o.connect(g); g.connect(c.destination);
        g.gain.setValueAtTime(0.5, c.currentTime); g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + cfg[2]);
        o.start(); o.stop(c.currentTime + cfg[2]); setTimeout(() => c.close(), 800);
    } catch (e) {}
}
let metroTimer = null;
function startMetronome() {
    stopMetronome();
    const bpm = parseInt($('metronomeRange').value) || 120;
    const tick = () => { playNote(1000); const c = $('metronomeCircle'); c.style.background = '#06b6d4'; setTimeout(() => c.style.background = '', 80); };
    tick(); metroTimer = setInterval(tick, 60000 / bpm);
}
function stopMetronome() { clearInterval(metroTimer); metroTimer = null; }

// ==================== 2048 ====================
function new2048() {
    game2048State = { grid: Array.from({ length: 4 }, () => Array(4).fill(0)), score: 0 };
    add2048Tile(); add2048Tile(); draw2048();
}
function add2048Tile() {
    const e = []; game2048State.grid.forEach((r, y) => r.forEach((v, x) => { if (!v) e.push([y, x]); }));
    if (!e.length) return;
    const [y, x] = e[Math.floor(Math.random() * e.length)];
    game2048State.grid[y][x] = Math.random() < 0.9 ? 2 : 4;
}
const TILE_COL = { 0: '#1e293b', 2: '#475569', 4: '#64748b', 8: '#f97316', 16: '#ea580c', 32: '#ef4444', 64: '#dc2626', 128: '#eab308', 256: '#facc15', 512: '#84cc16', 1024: '#22c55e', 2048: '#6366f1' };
function draw2048() {
    const b = $('g2048Board'); if (!b) return;
    b.innerHTML = game2048State.grid.flat().map(v => `<div class="g2048-cell" style="background:${TILE_COL[v] || '#8b5cf6'};color:#fff;font-size:${v > 999 ? 20 : 28}px">${v || ''}</div>`).join('');
    $('g2048Score').textContent = game2048State.score;
}
function slideRow(row) {
    let a = row.filter(v => v), s = 0;
    for (let i = 0; i < a.length - 1; i++) if (a[i] === a[i + 1]) { a[i] *= 2; s += a[i]; a.splice(i + 1, 1); }
    while (a.length < 4) a.push(0);
    return [a, s];
}
function move2048(dir) {
    const g = game2048State.grid; let moved = false, gain = 0;
    const get = i => dir === 'left' ? g[i].slice() : dir === 'right' ? g[i].slice().reverse() : dir === 'up' ? g.map(r => r[i]) : g.map(r => r[i]).reverse();
    for (let i = 0; i < 4; i++) {
        const before = get(i), [res, s] = slideRow(before); gain += s;
        if (res.join() !== before.join()) moved = true;
        const out = (dir === 'right' || dir === 'down') ? res.slice().reverse() : res;
        if (dir === 'left' || dir === 'right') g[i] = out; else out.forEach((v, y) => g[y][i] = v);
    }
    if (!moved) return;
    game2048State.score += gain; add2048Tile(); draw2048();
    const flat = g.flat();
    if (flat.includes(2048) && !game2048State.won) { game2048State.won = true; showToast('🎉 You reached 2048!', 'success'); }
    if (!flat.includes(0) && !canMove2048()) showToast('Game Over!', 'error');
}
function canMove2048() {
    const g = game2048State.grid;
    for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) if ((x < 3 && g[y][x] === g[y][x + 1]) || (y < 3 && g[y][x] === g[y + 1][x])) return true;
    return false;
}
function viewVisible(id) { const e = $(id); return e && !e.classList.contains('hidden'); }
document.addEventListener('keydown', e => {
    const map = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' };
    if (!map[e.key]) return;
    if (viewVisible('view-game2048') && !/INPUT|TEXTAREA/.test(e.target.tagName)) { e.preventDefault(); move2048(map[e.key]); }
    else if (viewVisible('view-arcade') && snake.t && !/INPUT|TEXTAREA/.test(e.target.tagName)) {
        e.preventDefault(); const d = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] }[map[e.key]]; snakeDir(d[0], d[1]);
    }
});
(function swipe2048() {
    let sx, sy;
    document.addEventListener('touchstart', e => { if (viewVisible('view-game2048')) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; } }, { passive: true });
    document.addEventListener('touchend', e => {
        if (!viewVisible('view-game2048') || sx == null) return;
        const dx = e.changedTouches[0].clientX - sx, dy = e.changedTouches[0].clientY - sy; sx = null;
        if (Math.max(Math.abs(dx), Math.abs(dy)) < 30) return;
        move2048(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up'));
    }, { passive: true });
})();

// ==================== SUDOKU ====================
function newSudoku() {
    const base = (r, c) => (3 * (r % 3) + Math.floor(r / 3) + c) % 9;
    const shuffle = a => a.sort(() => Math.random() - 0.5);
    const g3 = [0, 1, 2], rows = [], cols = [];
    shuffle(g3.slice()).forEach(g => shuffle(g3.slice()).forEach(r => rows.push(g * 3 + r)));
    shuffle(g3.slice()).forEach(g => shuffle(g3.slice()).forEach(c => cols.push(g * 3 + c)));
    const nums = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);
    const sol = rows.map(r => cols.map(c => nums[base(r, c)]));
    const puzzle = sol.map(r => r.slice());
    let rm = 42; while (rm > 0) { const y = Math.floor(Math.random() * 9), x = Math.floor(Math.random() * 9); if (puzzle[y][x]) { puzzle[y][x] = 0; rm--; } }
    sudokuState = { sol, puzzle };
    const b = $('sudokuBoard'); if (!b) return;
    b.innerHTML = puzzle.flat().map((v, i) => {
        const y = Math.floor(i / 9), x = i % 9;
        const bd = `border-right:${x % 3 === 2 && x < 8 ? '2px solid #6366f1' : ''};border-bottom:${y % 3 === 2 && y < 8 ? '2px solid #6366f1' : ''}`;
        return v ? `<input class="sudoku-cell fixed" style="${bd};aspect-ratio:1;width:100%" value="${v}" readonly>`
            : `<input class="sudoku-cell" style="${bd};aspect-ratio:1;width:100%" maxlength="1" inputmode="numeric" oninput="this.value=this.value.replace(/[^1-9]/g,'');this.classList.remove('err')">`;
    }).join('');
}
function checkSudoku() {
    const cells = document.querySelectorAll('#sudokuBoard .sudoku-cell'); let ok = true, empty = false;
    cells.forEach((c, i) => {
        if (c.readOnly) return;
        const y = Math.floor(i / 9), x = i % 9;
        if (!c.value) { empty = true; return; }
        if (+c.value !== sudokuState.sol[y][x]) { c.classList.add('err'); ok = false; } else c.classList.remove('err');
    });
    if (!ok) showToast('❌ কিছু ঘর ভুল (লাল)', 'error');
    else if (empty) showToast('এখন পর্যন্ত ঠিক আছে, চালিয়ে যান!', 'info');
    else { showToast('🎉 Solved!', 'success'); playSound('success'); }
}

// ==================== RPS / SLOT ====================
let rps = { w: 0, t: 0, l: 0 };
function playRPS(p) {
    const o = ['rock', 'paper', 'scissors'], em = { rock: '✊', paper: '✋', scissors: '✌️' }, c = o[Math.floor(Math.random() * 3)];
    let msg;
    if (p === c) { rps.t++; msg = 'Tie!'; }
    else if ((p === 'rock' && c === 'scissors') || (p === 'paper' && c === 'rock') || (p === 'scissors' && c === 'paper')) { rps.w++; msg = 'You win! 🎉'; }
    else { rps.l++; msg = 'CPU wins 😅'; }
    $('rpsResult').textContent = `${em[p]} vs ${em[c]}`; $('rpsMessage').textContent = msg;
    $('rpsWins').textContent = rps.w; $('rpsTies').textContent = rps.t; $('rpsLosses').textContent = rps.l;
}
let slotScore = 0, slotBusy = false;
function spinSlot() {
    if (slotBusy) return; slotBusy = true;
    const sy = ['🍒', '🍋', '🔔', '⭐', '💎', '7️⃣'], reels = $('slotReels').children; let n = 0;
    const t = setInterval(() => {
        [...reels].forEach(r => r.textContent = sy[Math.floor(Math.random() * sy.length)]);
        if (++n > 12) {
            clearInterval(t); slotBusy = false;
            const v = [...reels].map(r => r.textContent);
            if (v[0] === v[1] && v[1] === v[2]) { slotScore += 100; $('slotMessage').textContent = '🎰 JACKPOT! +100'; playSound('success'); }
            else if (v[0] === v[1] || v[1] === v[2] || v[0] === v[2]) { slotScore += 10; $('slotMessage').textContent = 'Nice! +10'; }
            else { $('slotMessage').textContent = 'Try again!'; }
            $('slotScore').textContent = slotScore;
        }
    }, 80);
}

// ==================== CUSTOM APPS ====================
function openAddAppModal() { $('newAppName').value = ''; $('newAppUrl').value = ''; $('addAppModal').classList.remove('hidden'); }
function closeAddAppModal() { $('addAppModal').classList.add('hidden'); }
function saveNewCustomApp() {
    const name = $('newAppName').value.trim(); let url = $('newAppUrl').value.trim();
    if (!name || !url) return showToast('নাম ও URL দিন', 'error');
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
    customApps.push({ id: Date.now().toString(), name, url }); saveCustomApps(); closeAddAppModal(); renderCustomApps();
    showToast('✅ App added', 'success');
}
function deleteCustomApp(id) { customApps = customApps.filter(a => a.id !== id); saveCustomApps(); renderCustomApps(); }
function renderCustomApps() {
    const g = $('customAppsGrid'); if (!g) return;
    g.innerHTML = customApps.map(a => `
        <div class="glass-card p-5 rounded-2xl flex items-center justify-between gap-3">
            <div onclick="window.open(this.dataset.url,'_blank','noopener')" data-url="${a.url.replace(/"/g, '&quot;')}" class="flex-1 min-w-0 cursor-pointer">
                <p class="text-sm font-bold text-white truncate"><i class="fa-solid fa-globe text-cyan-400 mr-2"></i>${escapeHtml(a.name)}</p>
                <p class="text-[10px] text-slate-500 truncate">${escapeHtml(a.url)}</p>
            </div>
            <button onclick="deleteCustomApp('${a.id}')" class="text-slate-500 hover:text-red-400"><i class="fa-solid fa-trash text-xs"></i></button>
        </div>`).join('') || '<p class="text-xs text-slate-500 col-span-full text-center py-8">কোনো app নেই — Add App চাপুন</p>';
    const b = $('customAppsCount'); if (b) b.textContent = customApps.length;
}

// ==================== ARCADE: SNAKE ====================
let snake = { t: null };
function startSnake() {
    clearInterval(snake.t);
    snake = { t: null, body: [{ x: 7, y: 7 }], dir: { x: 1, y: 0 }, next: { x: 1, y: 0 }, food: { x: 3, y: 3 }, score: 0 };
    $('snakeScore').textContent = 0; snake.t = setInterval(snakeTick, 130);
}
function snakeDir(dx, dy) { if (!snake.body) return; if (dx !== -snake.dir.x || dy !== -snake.dir.y) snake.next = { x: dx, y: dy }; }
function snakeTick() {
    const s = snake; s.dir = s.next;
    const h = { x: s.body[0].x + s.dir.x, y: s.body[0].y + s.dir.y };
    if (h.x < 0 || h.y < 0 || h.x >= 15 || h.y >= 15 || s.body.some(b => b.x === h.x && b.y === h.y)) {
        clearInterval(s.t); s.t = null; $('snakeScore').textContent = s.score + ' — Game Over'; playSound('error'); return;
    }
    s.body.unshift(h);
    if (h.x === s.food.x && h.y === s.food.y) {
        s.score++; $('snakeScore').textContent = s.score;
        do { s.food = { x: Math.floor(Math.random() * 15), y: Math.floor(Math.random() * 15) }; } while (s.body.some(b => b.x === s.food.x && b.y === s.food.y));
    } else s.body.pop();
    drawSnake();
}
function drawSnake() {
    const c = $('snakeCanvas'); if (!c) return; const x = c.getContext('2d');
    x.fillStyle = '#020617'; x.fillRect(0, 0, 300, 300);
    if (!snake.body) return;
    x.fillStyle = '#ef4444'; x.fillRect(snake.food.x * 20 + 2, snake.food.y * 20 + 2, 16, 16);
    snake.body.forEach((b, i) => { x.fillStyle = i ? '#22c55e' : '#86efac'; x.fillRect(b.x * 20 + 1, b.y * 20 + 1, 18, 18); });
}

// ==================== ARCADE: TIC TAC TOE ====================
let ttt = { b: Array(9).fill(''), over: false };
function newTTT() { ttt = { b: Array(9).fill(''), over: false }; drawTTT(); $('tttMsg').textContent = 'Your turn'; }
function drawTTT() {
    $('tttBoard').innerHTML = ttt.b.map((v, i) => `<button onclick="tttMove(${i})" class="h-20 rounded-xl bg-slate-800 hover:bg-slate-700 text-3xl font-extrabold ${v === 'X' ? 'text-cyan-400' : 'text-pink-400'}">${v}</button>`).join('');
}
function tttWinner(b) {
    const L = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
    for (const [a, c, d] of L) if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a];
    return b.every(v => v) ? 'tie' : null;
}
function tttMove(i) {
    if (ttt.over || ttt.b[i]) return;
    ttt.b[i] = 'X'; let w = tttWinner(ttt.b);
    if (!w) { const e = ttt.b.map((v, k) => v ? null : k).filter(k => k !== null); ttt.b[e[Math.floor(Math.random() * e.length)]] = 'O'; w = tttWinner(ttt.b); }
    drawTTT();
    if (w) { ttt.over = true; $('tttMsg').textContent = w === 'tie' ? "It's a tie!" : w === 'X' ? 'You win! 🎉' : 'CPU wins 😅'; }
}

// ==================== ARCADE: MEMORY ====================
let mem = { cards: [], open: [], moves: 0, lock: false };
function newMemory() {
    const e = ['🍎', '🚀', '🎧', '🌙', '🔥', '🐱', '💎', '🎯'];
    mem = { cards: [...e, ...e].sort(() => Math.random() - 0.5).map(v => ({ v, up: false, done: false })), open: [], moves: 0, lock: false };
    drawMemory();
}
function drawMemory() {
    $('memBoard').innerHTML = mem.cards.map((c, i) => `<button onclick="memFlip(${i})" class="h-16 rounded-xl text-2xl ${c.up || c.done ? 'bg-indigo-600' : 'bg-slate-800'}">${c.up || c.done ? c.v : '?'}</button>`).join('');
    $('memMoves').textContent = mem.moves;
}
function memFlip(i) {
    const c = mem.cards[i]; if (mem.lock || c.up || c.done) return;
    c.up = true; mem.open.push(i); drawMemory();
    if (mem.open.length === 2) {
        mem.moves++; mem.lock = true;
        const [a, b] = mem.open;
        setTimeout(() => {
            if (mem.cards[a].v === mem.cards[b].v) { mem.cards[a].done = mem.cards[b].done = true; }
            mem.cards[a].up = mem.cards[b].up = false; mem.open = []; mem.lock = false; drawMemory();
            if (mem.cards.every(x => x.done)) { showToast(`🎉 ${mem.moves} moves এ শেষ!`, 'success'); playSound('success'); }
        }, 600);
    }
}

// ==================== ARCADE: REACTION ====================
let react = { state: 'idle', t0: 0, to: null };
function reactClick() {
    const b = $('reactBtn'), m = $('reactMsg');
    if (react.state === 'idle') {
        react.state = 'wait'; b.textContent = 'Wait for green...'; b.className = 'w-full h-40 rounded-2xl bg-red-600 text-white font-bold text-lg';
        react.to = setTimeout(() => { react.state = 'go'; react.t0 = performance.now(); b.textContent = 'CLICK!'; b.className = 'w-full h-40 rounded-2xl bg-emerald-500 text-white font-bold text-lg'; }, 1500 + Math.random() * 2500);
    } else if (react.state === 'wait') {
        clearTimeout(react.to); react.state = 'idle'; m.textContent = 'Too early! Try again.';
        b.textContent = 'Click to start'; b.className = 'w-full h-40 rounded-2xl bg-slate-800 text-white font-bold text-lg';
    } else {
        const ms = Math.round(performance.now() - react.t0); react.state = 'idle'; m.textContent = `⚡ ${ms} ms`;
        b.textContent = 'Click to start'; b.className = 'w-full h-40 rounded-2xl bg-slate-800 text-white font-bold text-lg';
    }
}

// ==================== VIDEO STUDIO ====================
function loadVideo(e) {
    const f = e.target.files[0]; if (!f) return;
    const v = $('studioVideo'); if (v.dataset.url) URL.revokeObjectURL(v.dataset.url);
    v.dataset.url = URL.createObjectURL(f); v.src = v.dataset.url; applyVideoFx();
}
function applyVideoFx() {
    const v = $('studioVideo');
    v.style.filter = `brightness(${$('vfBright').value}%) contrast(${$('vfContrast').value}%) saturate(${$('vfSat').value}%) grayscale(${$('vfGray').value}%)`;
    v.playbackRate = parseFloat($('vfSpeed').value);
}
function videoSnapshot() {
    const v = $('studioVideo'); if (!v.videoWidth) return showToast('আগে ভিডিও দিন', 'error');
    const c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight;
    const x = c.getContext('2d'); x.filter = v.style.filter; x.drawImage(v, 0, 0);
    const a = document.createElement('a'); a.href = c.toDataURL('image/png'); a.download = 'snapshot.png'; a.click();
}

// ==================== DESIGN STUDIO ====================
let dsEraser = false, dsDrawing = false;
function dsInit() {
    const c = $('dsCanvas'); if (!c || c.dataset.ready) return; c.dataset.ready = '1';
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.lineCap = 'round'; x.lineJoin = 'round';
    const pos = e => { const r = c.getBoundingClientRect(); return [(e.clientX - r.left) * c.width / r.width, (e.clientY - r.top) * c.height / r.height]; };
    c.addEventListener('pointerdown', e => { dsDrawing = true; c.setPointerCapture(e.pointerId); const [px, py] = pos(e); x.beginPath(); x.moveTo(px, py); });
    c.addEventListener('pointermove', e => {
        if (!dsDrawing) return; const [px, py] = pos(e);
        x.strokeStyle = dsEraser ? '#fff' : $('dsColor').value; x.lineWidth = $('dsSize').value; x.lineTo(px, py); x.stroke();
    });
    ['pointerup', 'pointercancel'].forEach(ev => c.addEventListener(ev, () => dsDrawing = false));
}
function dsClear() { const c = $('dsCanvas'), x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); }
function dsDownload() { const a = document.createElement('a'); a.href = $('dsCanvas').toDataURL('image/png'); a.download = 'design.png'; a.click(); }

// ==================== DEVELOPER ====================
function urlTool(enc) { try { $('urlOut').value = enc ? encodeURIComponent($('urlIn').value) : decodeURIComponent($('urlIn').value); } catch (e) { $('urlOut').value = '❌ Invalid'; } }
function textStats() { const t = $('txtIn').value; $('txtStats').textContent = `${t.trim() ? t.trim().split(/\s+/).length : 0} words · ${t.length} chars`; }
function caseTool(m) {
    const e = $('txtIn'), t = e.value;
    e.value = m === 'up' ? t.toUpperCase() : m === 'low' ? t.toLowerCase() : t.toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
    textStats();
}
function tsTool() {
    const v = $('tsIn').value.trim(), d = v ? new Date(parseInt(v) * 1000) : new Date();
    $('tsOut').textContent = isNaN(d) ? '❌ Invalid' : `${Math.floor(d / 1000)}\n${d.toISOString()}\n${d.toLocaleString()}`;
    $('tsOut').style.whiteSpace = 'pre-line';
}
function hexTool() {
    let h = $('hexIn').value.trim().replace('#', '');
    if (h.length === 3) h = h.split('').map(c => c + c).join('');
    if (!/^[0-9a-fA-F]{6}$/.test(h)) { $('hexOut').textContent = '-'; $('hexSwatch').style.background = ''; return; }
    const n = parseInt(h, 16); $('hexOut').textContent = `rgb(${n >> 16}, ${(n >> 8) & 255}, ${n & 255})`; $('hexSwatch').style.background = '#' + h;
}

// ==================== TODO ====================
function addTodo() {
    const v = $('todoInput').value.trim(); if (!v) return;
    todos.unshift({ id: Date.now().toString(), text: v, done: false }); saveTodos(); $('todoInput').value = ''; renderTodos();
}
function toggleTodo(id) { const t = todos.find(x => x.id === id); if (t) t.done = !t.done; saveTodos(); renderTodos(); }
function deleteTodo(id) { todos = todos.filter(t => t.id !== id); saveTodos(); renderTodos(); }
function renderTodos() {
    const l = $('todoList'); if (!l) return;
    $('todoCount').textContent = `${todos.filter(t => !t.done).length} pending · ${todos.length} total`;
    l.innerHTML = todos.map(t => `
        <div class="glass-card p-3 rounded-xl flex items-center gap-3">
            <button onclick="toggleTodo('${t.id}')" class="w-6 h-6 rounded-md border-2 ${t.done ? 'bg-teal-500 border-teal-500' : 'border-slate-600'} flex items-center justify-center text-white text-[10px]">${t.done ? '<i class="fa-solid fa-check"></i>' : ''}</button>
            <span class="flex-1 text-sm ${t.done ? 'line-through text-slate-500' : 'text-white'}">${escapeHtml(t.text)}</span>
            <button onclick="deleteTodo('${t.id}')" class="text-slate-500 hover:text-red-400 text-xs"><i class="fa-solid fa-trash"></i></button>
        </div>`).join('') || '<p class="text-xs text-slate-500 text-center py-4">কোনো task নেই 🎉</p>';
}

console.log('%c📦 PART 3 Loaded', 'color:#10b981;font-size:14px;font-weight:bold');
