# Ultra Suite — Render এ চালানোর গাইড

## ফোল্ডার
```
ultra-suite/
├── server.js          ← backend (নতুন)
├── package.json
├── render.yaml
├── .env.example
└── public/            ← ব্রাউজারে যা যায়
    ├── index.html     ← আপনার ফাইল (এখানে কপি করুন)
    ├── part2.js       ← নতুন (এই প্যাকেজের)
    ├── part3.js       ← আপনার part3.js + part3-continue.js জোড়া দেওয়া
    ├── pwa.js, sw.js, manifest.json, icons/
    └── logo.png       ← আপনার লোগো (এই নামে রাখুন)
```

## ১) আপনাকে যা করতে হবে (ফাইল)
1. আপনার `index.html` → `public/` এ রাখুন।
2. `index.html` এর শেষে `part3.js` এর নিচে এক লাইন যোগ করুন: `<script src="pwa.js"></script>`
3. আপনার `part3.js` এর ভাঙা `function customAppsView() {` থেকে শেষ পর্যন্ত মুছে `part3-continue.js` এর পুরোটা পেস্ট করে `public/part3.js` নামে রাখুন।
4. আপনার ছবিটা `public/logo.png` নামে রাখুন (সার্ভার নিজে ১৯২/৫১২ আইকন বানিয়ে নেবে)।
5. পুরনো `part2.js` ফেলে দিন — নতুনটাই `public/part2.js`।

## ২) MongoDB Atlas (ফ্রি ডেটাবেস)
1. mongodb.com/atlas → ফ্রি অ্যাকাউন্ট → **Create Cluster (M0 Free)**।
2. **Database Access** → Add User → username/password দিন (মনে রাখুন)।
3. **Network Access** → Add IP → `0.0.0.0/0` (Allow from anywhere)।
4. **Connect → Drivers** থেকে connection string কপি করুন, যেমন
   `mongodb+srv://USER:PASS@cluster0.xxxx.mongodb.net/` — `PASS` এর জায়গায় আপনার পাসওয়ার্ড বসান।

## ৩) GitHub → Render
1. ফোল্ডারটা GitHub এ নতুন (Private) repo হিসেবে আপলোড করুন (`node_modules` ও `.env` দেবেন না)।
2. render.com → **New + → Web Service** → repo বেছে নিন।
3. Build Command: `npm install` | Start Command: `npm start`
4. **Environment** এ যোগ করুন:
   | Key | Value |
   |---|---|
   | `NODE_ENV` | `production` |
   | `ADMIN_PASSWORD` | আপনার নতুন গোপন পাসওয়ার্ড (৬+ অক্ষর) |
   | `JWT_SECRET` | যেকোনো লম্বা র‍্যান্ডম লেখা (৩২+ অক্ষর) |
   | `MONGODB_URI` | ধাপ ২ এর connection string |
5. Deploy চাপুন। লগে `💾 Storage: MongoDB` দেখলে ঠিক আছে।

## ৪) লোকালে টেস্ট (ঐচ্ছিক)
```
npm install
cp .env.example .env     # ADMIN_PASSWORD বদলান
npm start                # http://localhost:3000
```

## জেনে রাখুন
- **Admin পাসওয়ার্ড** এখন শুধু Render এর Environment এ — কোডে নেই। বদলাতে ওখানে বদলে Redeploy করুন।
- আগে কোডে যে পাসওয়ার্ড ছিল (`wifeysamia`) সেটা আর ব্যবহার করবেন না।
- ইউজারনেম: ৩-২০ অক্ষর, শুধু `a-z 0-9 _ .` — পাসওয়ার্ড কমপক্ষে ৬ অক্ষর।
- Notes, Todo, Expense, Habits ইত্যাদি এখনো **ওই ডিভাইসেই** সেভ হয়। Chat, ইউজার, Admin সব সার্ভারে।
- Render ফ্রি প্ল্যানে ১৫ মিনিট কেউ না আসলে সার্ভার ঘুমায়; প্রথম খোলায় ৩০-৬০ সেকেন্ড লাগতে পারে।
- Chat প্রতি ~২.৫ সেকেন্ডে আপডেট হয় (real-time socket নয়, polling)।
- ছবি/ভয়েস সর্বোচ্চ ~২.৫MB।
