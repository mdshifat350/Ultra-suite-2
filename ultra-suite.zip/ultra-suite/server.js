// ==================== ULTRA SUITE SERVER ====================
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const PORT = process.env.PORT || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';
const PUB = path.join(__dirname, 'public');

// ---------- Secrets (কোডে নয়, Environment Variables এ) ----------
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
if (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 6) {
  console.error('❌ ADMIN_PASSWORD সেট করা নেই (কমপক্ষে ৬ অক্ষর). Render → Environment এ যোগ করুন।');
  process.exit(1);
}
const ADMIN_USERNAME = (process.env.ADMIN_USERNAME || 'wifey_samia').toLowerCase();
let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  JWT_SECRET = crypto.randomBytes(48).toString('hex');
  console.warn('⚠️  JWT_SECRET সেট নেই — রিস্টার্ট হলে সবাই logout হয়ে যাবে।');
}

// ---------- Storage: MongoDB (প্রোডাকশন) অথবা JSON ফাইল (টেস্ট) ----------
const match = (d, q) => Object.entries(q || {}).every(([k, v]) => d[k] === v);
const omitKeys = (d, omit) => { const c = { ...d }; (omit || []).forEach(k => delete c[k]); return c; };

function fileStore(file) {
  let data = { users: [], messages: [], logs: [], settings: [] };
  try { data = { ...data, ...JSON.parse(fs.readFileSync(file, 'utf8')) }; } catch (e) {}
  let t = null;
  const flush = () => { clearTimeout(t); t = setTimeout(() => fs.writeFile(file, JSON.stringify(data), () => {}), 300); };
  const col = n => ({
    async find(q, omit) { return data[n].filter(d => match(d, q)).map(d => omitKeys(d, omit)); },
    async findOne(q) { const d = data[n].find(d => match(d, q)); return d ? { ...d } : null; },
    async insert(doc) { data[n].push({ ...doc }); flush(); return doc; },
    async update(q, patch) { data[n].forEach(d => { if (match(d, q)) Object.assign(d, patch); }); flush(); },
    async remove(q) { data[n] = data[n].filter(d => !match(d, q)); flush(); },
    async count(q) { return data[n].filter(d => match(d, q)).length; }
  });
  return { col, kind: 'JSON file (শুধু টেস্টের জন্য)' };
}

async function mongoStore(uri) {
  const { MongoClient } = require('mongodb');
  const client = new MongoClient(uri);
  await client.connect();
  const db = client.db(process.env.MONGODB_DB || 'ultrasuite');
  await db.collection('users').createIndex({ username: 1 }, { unique: true });
  await db.collection('users').createIndex({ id: 1 }, { unique: true });
  await db.collection('messages').createIndex({ chat: 1, ts: 1 });
  await db.collection('messages').createIndex({ id: 1 });
  await db.collection('messages').createIndex({ to: 1, read: 1 });
  const col = n => {
    const k = db.collection(n);
    const proj = omit => { const p = { _id: 0 }; (omit || []).forEach(f => p[f] = 0); return p; };
    return {
      find: (q, omit) => k.find(q || {}, { projection: proj(omit) }).toArray(),
      findOne: q => k.findOne(q, { projection: { _id: 0 } }),
      insert: async d => { await k.insertOne({ ...d }); return d; },
      update: (q, p) => k.updateMany(q, { $set: p }),
      remove: q => k.deleteMany(q),
      count: q => k.countDocuments(q || {})
    };
  };
  return { col, kind: 'MongoDB' };
}

// ---------- Helpers ----------
const wrap = fn => (req, res, next) => fn(req, res, next).catch(next);
const clean = (s, n) => String(s == null ? '' : s).replace(/[<>]/g, '').trim().slice(0, n);
const chatKey = (a, b) => [a, b].sort().join('_');
const validAvatar = a => a == null || a === '' || (typeof a === 'string' && /^data:image\/(png|jpe?g|webp|gif);base64,/.test(a) && a.length < 500000);
const DATA_RE = /^data:([\w.+-]+\/[\w.+-]+)(?:;[^,;]+)*;base64,([A-Za-z0-9+/=]+)$/;
const ONLINE_MS = 70 * 1000;

const publicUser = u => ({
  id: u.id, username: u.username, displayName: u.displayName, avatar: u.avatar || null, bio: u.bio || '',
  isAdmin: !!u.isAdmin, status: u.status, joined: u.joined, lastActive: u.lastActive || 0,
  isOnline: u.status === 'active' && Date.now() - (u.lastActive || 0) < ONLINE_MS
});
const lightMsg = m => ({ id: m.id, from: m.from, to: m.to, ts: m.ts, read: !!m.read, type: m.type, text: m.text || '' });

async function makeIcons() {
  const logo = path.join(PUB, 'logo.png');
  if (!fs.existsSync(logo)) return;
  let sharp; try { sharp = require('sharp'); } catch (e) { console.warn('sharp নেই — logo.png থেকে আইকন বানানো হয়নি'); return; }
  const out = path.join(PUB, 'icons'); fs.mkdirSync(out, { recursive: true });
  for (const [name, s, pad] of [['icon-192.png', 192, 0], ['icon-512.png', 512, 0], ['apple-touch-icon.png', 180, 0], ['maskable-512.png', 512, 0.14]]) {
    const inner = Math.round(s * (1 - 2 * pad));
    const buf = await sharp(logo).resize(inner, inner, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toBuffer();
    await sharp({ create: { width: s, height: s, channels: 4, background: pad || name.startsWith('apple') ? '#070a12' : { r: 0, g: 0, b: 0, alpha: 0 } } })
      .composite([{ input: buf }]).png().toFile(path.join(out, name));
  }
  console.log('🖼️  logo.png থেকে আইকন তৈরি হয়েছে');
}

// ==================== MAIN ====================
(async () => {
  const store = process.env.MONGODB_URI ? await mongoStore(process.env.MONGODB_URI) : fileStore(path.join(__dirname, 'data.json'));
  console.log('💾 Storage:', store.kind);
  if (IS_PROD && !process.env.MONGODB_URI) console.warn('⚠️  MONGODB_URI নেই — Render এ ডেটা রিস্টার্টে মুছে যাবে!');
  const users = store.col('users'), messages = store.col('messages'), logs = store.col('logs'), settings = store.col('settings');

  const addLog = (action, user) => logs.insert({ ts: Date.now(), action, user: user || 'guest' }).catch(() => {});
  const getSettings = async () => { const s = await settings.findOne({ key: 'site' }); return { siteName: (s && s.siteName) || 'Ultra Suite', announcement: (s && s.announcement) || '' }; };

  // ---- Admin account (পাসওয়ার্ড env থেকে, hash করে) ----
  const adminHash = bcrypt.hashSync(ADMIN_PASSWORD, 10);
  const existingAdmin = await users.findOne({ username: ADMIN_USERNAME });
  if (existingAdmin) await users.update({ username: ADMIN_USERNAME }, { passwordHash: adminHash, isAdmin: true, status: 'active' });
  else await users.insert({
    id: crypto.randomUUID(), username: ADMIN_USERNAME, displayName: 'Wifey Samia', passwordHash: adminHash, status: 'active',
    joined: new Date().toISOString().split('T')[0], lastLogin: null, lastActive: 0, visits: 0, isAdmin: true, avatar: null, bio: 'Admin of Ultra Suite 👑'
  });
  const dummyHash = bcrypt.hashSync('dummy-password', 10);

  const app = express();
  app.set('trust proxy', 1);
  app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
  app.use(express.json({ limit: '6mb' }));
  app.use(cookieParser());
  app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, max: 6000, standardHeaders: true, legacyHeaders: false }));
  const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 25, standardHeaders: true, legacyHeaders: false, message: { error: 'অনেকবার চেষ্টা হয়েছে, ১৫ মিনিট পরে আবার চেষ্টা করুন' } });
  const adminLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 8, standardHeaders: true, legacyHeaders: false, message: { error: 'অনেকবার ভুল হয়েছে, ১৫ মিনিট অপেক্ষা করুন' } });

  const cookieOpts = maxAge => ({ httpOnly: true, sameSite: 'lax', secure: IS_PROD, maxAge, path: '/' });
  const setUserCookie = (res, uid) => res.cookie('us_token', jwt.sign({ uid }, JWT_SECRET, { expiresIn: '30d' }), cookieOpts(30 * 864e5));

  async function auth(req, res, next) {
    try {
      const p = jwt.verify(req.cookies.us_token || '', JWT_SECRET);
      const u = await users.findOne({ id: p.uid });
      if (!u || u.status === 'banned') return res.status(401).json({ error: 'Session শেষ — আবার login করুন' });
      req.user = u; next();
    } catch (e) { res.status(401).json({ error: 'আগে login করুন' }); }
  }
  function adminAuth(req, res, next) {
    try { const p = jwt.verify(req.cookies.us_admin || '', JWT_SECRET); if (!p.admin) throw 0; next(); }
    catch (e) { res.status(401).json({ error: 'Admin access দরকার' }); }
  }

  // ---------- Auth ----------
  app.get('/healthz', (req, res) => res.send('ok'));

  app.get('/api/username', wrap(async (req, res) => {
    const u = String(req.query.u || '').trim().toLowerCase();
    if (!/^[a-z0-9_.]{3,20}$/.test(u)) return res.json({ available: false, error: 'ইউজারনেম ৩-২০ অক্ষর, শুধু a-z, 0-9, _ এবং .' });
    const taken = u === ADMIN_USERNAME || !!(await users.findOne({ username: u }));
    res.json({ available: !taken, error: taken ? 'এই ইউজারনেম আগেই নেওয়া হয়েছে' : '' });
  }));

  app.post('/api/signup', authLimiter, wrap(async (req, res) => {
    const b = req.body || {};
    const username = String(b.username || '').trim().toLowerCase();
    const password = String(b.password || '');
    if (!/^[a-z0-9_.]{3,20}$/.test(username)) return res.status(400).json({ error: 'ইউজারনেম ৩-২০ অক্ষর, শুধু a-z, 0-9, _ এবং .' });
    if (password.length < 6 || password.length > 72) return res.status(400).json({ error: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষর' });
    if (!validAvatar(b.avatar)) return res.status(400).json({ error: 'ছবি সঠিক নয় বা বেশি বড়' });
    if (username === ADMIN_USERNAME || await users.findOne({ username })) return res.status(409).json({ error: 'এই ইউজারনেম আগেই নেওয়া হয়েছে' });
    const u = {
      id: crypto.randomUUID(), username, displayName: clean(b.displayName, 30) || username, passwordHash: await bcrypt.hash(password, 10),
      status: 'active', joined: new Date().toISOString().split('T')[0], lastLogin: new Date().toISOString(), lastActive: Date.now(), visits: 1,
      isAdmin: false, avatar: b.avatar || null, bio: clean(b.bio, 80)
    };
    try { await users.insert(u); } catch (e) { return res.status(409).json({ error: 'এই ইউজারনেম আগেই নেওয়া হয়েছে' }); }
    addLog('New account created: ' + username, username);
    setUserCookie(res, u.id);
    res.json({ user: publicUser(u) });
  }));

  app.post('/api/login', authLimiter, wrap(async (req, res) => {
    const username = String((req.body || {}).username || '').trim().toLowerCase();
    const password = String((req.body || {}).password || '');
    const u = await users.findOne({ username });
    const ok = await bcrypt.compare(password, u ? u.passwordHash : dummyHash);
    if (!u) return res.status(401).json({ error: 'এই ইউজারনেমে অ্যাকাউন্ট নেই। Sign Up করুন।' });
    if (!ok) return res.status(401).json({ error: 'ভুল পাসওয়ার্ড!' });
    if (u.status === 'banned') return res.status(403).json({ error: 'আপনার অ্যাকাউন্ট ব্যান করা হয়েছে' });
    await users.update({ id: u.id }, { lastLogin: new Date().toISOString(), lastActive: Date.now(), visits: (u.visits || 0) + 1 });
    addLog(username + ' logged in', username);
    setUserCookie(res, u.id);
    res.json({ user: publicUser(u) });
  }));

  app.post('/api/logout', wrap(async (req, res) => {
    try { const p = jwt.verify(req.cookies.us_token || '', JWT_SECRET); await users.update({ id: p.uid }, { lastActive: 0 }); } catch (e) {}
    res.clearCookie('us_token', { path: '/' }); res.json({ ok: true });
  }));

  app.get('/api/me', auth, wrap(async (req, res) => {
    await users.update({ id: req.user.id }, { lastActive: Date.now() });
    res.json({ user: publicUser(req.user), settings: await getSettings() });
  }));

  app.put('/api/me', auth, wrap(async (req, res) => {
    const b = req.body || {}, patch = {};
    if ('displayName' in b) patch.displayName = clean(b.displayName, 30) || req.user.username;
    if ('bio' in b) patch.bio = clean(b.bio, 80);
    if ('avatar' in b) { if (!validAvatar(b.avatar)) return res.status(400).json({ error: 'ছবি সঠিক নয়' }); patch.avatar = b.avatar || null; }
    if (b.password) {
      if (req.user.isAdmin) return res.status(400).json({ error: 'Admin পাসওয়ার্ড Render এর ADMIN_PASSWORD থেকে বদলান' });
      if (String(b.password).length < 6 || String(b.password).length > 72) return res.status(400).json({ error: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষর' });
      patch.passwordHash = await bcrypt.hash(String(b.password), 10);
    }
    await users.update({ id: req.user.id }, patch);
    res.json({ user: publicUser({ ...req.user, ...patch }) });
  }));

  app.post('/api/ping', auth, wrap(async (req, res) => { await users.update({ id: req.user.id }, { lastActive: Date.now() }); res.json({ ok: true }); }));
  app.get('/api/settings', auth, wrap(async (req, res) => res.json(await getSettings())));

  app.get('/api/users', auth, wrap(async (req, res) => {
    const all = await users.find({ status: 'active' }, ['passwordHash']);
    res.json({ users: all.map(publicUser) });
  }));

  // ---------- Messages ----------
  app.get('/api/chats', auth, wrap(async (req, res) => {
    const me = req.user.id;
    const [a, b] = await Promise.all([messages.find({ from: me }, ['data']), messages.find({ to: me }, ['data'])]);
    const chats = {}; let total = 0;
    for (const m of [...a, ...b]) {
      const other = m.from === me ? m.to : m.from;
      const c = chats[other] || (chats[other] = { last: null, unread: 0 });
      if (!c.last || m.ts > c.last.ts) c.last = { type: m.type, text: m.text || '', from: m.from, ts: m.ts };
      if (m.to === me && !m.read) { c.unread++; total++; }
    }
    res.json({ chats, total });
  }));

  app.get('/api/messages/:id', auth, wrap(async (req, res) => {
    const other = await users.findOne({ id: req.params.id });
    if (!other) return res.status(404).json({ error: 'ইউজার পাওয়া যায়নি' });
    const chat = chatKey(req.user.id, other.id);
    if (req.query.markRead === '1') await messages.update({ chat, to: req.user.id, read: false }, { read: true });
    const list = (await messages.find({ chat }, ['data'])).sort((x, y) => x.ts - y.ts).slice(-200);
    res.json({ messages: list.map(lightMsg) });
  }));

  app.post('/api/messages', auth, wrap(async (req, res) => {
    const b = req.body || {};
    const to = await users.findOne({ id: String(b.to || '') });
    if (!to || to.status !== 'active' || to.id === req.user.id) return res.status(400).json({ error: 'এই ইউজারকে মেসেজ পাঠানো যাবে না' });
    const type = ['text', 'image', 'voice'].includes(b.type) ? b.type : 'text';
    const m = { id: crypto.randomUUID(), chat: chatKey(req.user.id, to.id), from: req.user.id, to: to.id, ts: Date.now(), read: false, type, text: '' };
    if (type === 'text') {
      m.text = String(b.text || '').slice(0, 2000);
      if (!m.text.trim()) return res.status(400).json({ error: 'খালি মেসেজ' });
    } else {
      const d = String(b.data || ''), mt = DATA_RE.exec(d);
      if (!mt || d.length > 3500000) return res.status(400).json({ error: 'ফাইল সঠিক নয় বা বেশি বড় (সর্বোচ্চ ~২.৫MB)' });
      if (!mt[1].startsWith(type === 'image' ? 'image/' : 'audio/')) return res.status(400).json({ error: 'ফাইলের ধরন সঠিক নয়' });
      m.data = d; m.mime = mt[1];
    }
    await messages.insert(m);
    res.json({ message: lightMsg(m) });
  }));

  app.delete('/api/messages/:id', auth, wrap(async (req, res) => {
    await messages.remove({ chat: chatKey(req.user.id, req.params.id) });
    res.json({ ok: true });
  }));

  // মিডিয়া (ছবি/ভয়েস) — Range সাপোর্ট সহ (Safari এর জন্য দরকার)
  app.get('/api/media/:id', auth, wrap(async (req, res) => {
    const m = await messages.findOne({ id: req.params.id });
    if (!m || !m.data || (m.from !== req.user.id && m.to !== req.user.id)) return res.status(404).end();
    const mt = DATA_RE.exec(m.data); if (!mt) return res.status(404).end();
    const buf = Buffer.from(mt[2], 'base64');
    res.set({ 'Content-Type': m.mime || mt[1], 'Accept-Ranges': 'bytes', 'Cache-Control': 'private, max-age=86400', 'X-Content-Type-Options': 'nosniff' });
    const r = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
    if (r) {
      let s = r[1] === '' ? Math.max(buf.length - parseInt(r[2], 10), 0) : parseInt(r[1], 10);
      let e = r[1] === '' || r[2] === '' ? buf.length - 1 : Math.min(parseInt(r[2], 10), buf.length - 1);
      if (s > e || s >= buf.length) return res.status(416).set('Content-Range', `bytes */${buf.length}`).end();
      res.status(206).set({ 'Content-Range': `bytes ${s}-${e}/${buf.length}`, 'Content-Length': e - s + 1 }).end(buf.subarray(s, e + 1));
    } else res.set('Content-Length', buf.length).end(buf);
  }));

  // ---------- Admin ----------
  app.post('/api/admin/login', adminLimiter, wrap(async (req, res) => {
    const ok = await bcrypt.compare(String((req.body || {}).password || ''), adminHash);
    if (!ok) { addLog('Failed admin login attempt', 'unknown'); return res.status(401).json({ error: 'ভুল পাসওয়ার্ড!' }); }
    res.cookie('us_admin', jwt.sign({ admin: true }, JWT_SECRET, { expiresIn: '2h' }), cookieOpts(2 * 36e5));
    addLog('Admin panel unlocked', ADMIN_USERNAME);
    res.json({ ok: true });
  }));
  app.post('/api/admin/logout', (req, res) => { res.clearCookie('us_admin', { path: '/' }); res.json({ ok: true }); });

  app.get('/api/admin/overview', adminAuth, wrap(async (req, res) => {
    const all = await users.find({}, ['passwordHash']);
    const list = all.map(u => ({ ...publicUser(u), lastLogin: u.lastLogin, visits: u.visits || 0 }));
    const allLogs = (await logs.find({})).sort((a, b) => b.ts - a.ts).slice(0, 50);
    res.json({
      users: list, logs: allLogs, settings: await getSettings(),
      stats: { total: list.length, online: list.filter(u => u.isOnline).length, banned: list.filter(u => u.status === 'banned').length, messages: await messages.count({}) }
    });
  }));

  app.post('/api/admin/users/:id/ban', adminAuth, wrap(async (req, res) => {
    const u = await users.findOne({ id: req.params.id });
    if (!u || u.isAdmin) return res.status(400).json({ error: 'এই ইউজারকে ব্যান করা যাবে না' });
    const status = u.status === 'active' ? 'banned' : 'active';
    await users.update({ id: u.id }, { status, lastActive: 0 });
    addLog(`User ${u.username} ${status}`, ADMIN_USERNAME);
    res.json({ status });
  }));

  app.delete('/api/admin/users/:id', adminAuth, wrap(async (req, res) => {
    const u = await users.findOne({ id: req.params.id });
    if (!u || u.isAdmin) return res.status(400).json({ error: 'এই ইউজারকে মোছা যাবে না' });
    await users.remove({ id: u.id }); await messages.remove({ from: u.id }); await messages.remove({ to: u.id });
    addLog(`User ${u.username} deleted`, ADMIN_USERNAME);
    res.json({ ok: true });
  }));

  app.put('/api/admin/settings', adminAuth, wrap(async (req, res) => {
    const b = req.body || {}, cur = await getSettings();
    const next = { siteName: 'siteName' in b ? (clean(b.siteName, 40) || 'Ultra Suite') : cur.siteName, announcement: 'announcement' in b ? clean(b.announcement, 500) : cur.announcement };
    if (await settings.findOne({ key: 'site' })) await settings.update({ key: 'site' }, next); else await settings.insert({ key: 'site', ...next });
    res.json(next);
  }));

  app.delete('/api/admin/logs', adminAuth, wrap(async (req, res) => { await logs.remove({}); res.json({ ok: true }); }));

  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

  // ---------- Static ----------
  app.use(express.static(PUB, { dotfiles: 'ignore', setHeaders: (res, p) => { if (/sw\.js$|manifest\.json$/.test(p)) res.setHeader('Cache-Control', 'no-cache'); } }));

  app.use((err, req, res, next) => {
    console.error(err);
    if (err.type === 'entity.too.large') return res.status(413).json({ error: 'ফাইল অনেক বড়' });
    res.status(500).json({ error: 'সার্ভারে সমস্যা হয়েছে' });
  });

  makeIcons().catch(e => console.warn('icon error', e.message));
  app.listen(PORT, () => console.log(`🚀 Ultra Suite চলছে: http://localhost:${PORT}`));
})().catch(e => { console.error('Startup failed:', e); process.exit(1); });
