// ==================== PART 2 (SERVER VERSION): Auth, Messages, Admin, Notes, Alarm, Timer ====================
// Admin পাসওয়ার্ড এখানে নেই — সার্ভারে (Render Environment Variable) থাকে।

const CURRENCY = "৳";

// ==================== STATE ====================
let currentUser = null;
let currentAuthTab = 'login';
let soundEnabled = true;
let currentNoteId = null;
let timerInterval = null, stopwatchInterval = null, stopwatchTime = 0;
let timerSecondsLeft = 0, timerTotal = 0;
let alarms = JSON.parse(localStorage.getItem('ultra_alarms')) || [];
let notes = JSON.parse(localStorage.getItem('ultra_notes')) || [];
let notifications = JSON.parse(localStorage.getItem('ultra_notifications')) || [];
let siteSettings = { siteName: 'Ultra Suite', announcement: '' };
let selectedChatUser = null;
let usersCache = [], chatCache = [], chatSig = '', chatsMeta = {}, totalUnread = 0, chatsLoaded = false;
let pollers = [];
let mediaRecorder = null, audioChunks = [], recordingStartTime = 0, recordingTimer = null, recordingCancelled = false;
let adminData = null;

// ==================== HELPERS ====================
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function escapeHtml(t) { return esc(t); }
function byId(id) { return document.getElementById(id); }
function isOpen(id) { const e = byId(id); return !!e && !e.classList.contains('hidden'); }
function saveNotes() { localStorage.setItem('ultra_notes', JSON.stringify(notes)); }
function saveAlarms() { localStorage.setItem('ultra_alarms', JSON.stringify(alarms)); }
function saveNotifications() { localStorage.setItem('ultra_notifications', JSON.stringify(notifications)); }
function addLog() { /* লগ এখন সার্ভারে জমা হয় */ }

function addNotification(text, icon = 'info') {
    notifications.unshift({ id: Date.now(), text, icon, time: new Date().toLocaleString(), read: false });
    if (notifications.length > 50) notifications = notifications.slice(0, 50);
    saveNotifications(); updateNotifBadge();
}

async function api(path, method = 'GET', body) {
    const opt = { method, credentials: 'same-origin', headers: {} };
    if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    let r;
    try { r = await fetch('/api' + path, opt); } catch (e) { throw new Error('সার্ভারের সাথে যোগাযোগ করা যাচ্ছে না'); }
    let d = {};
    try { d = await r.json(); } catch (e) {}
    if (!r.ok) {
        if (r.status === 401 && currentUser && !path.startsWith('/admin')) sessionExpired();
        const err = new Error(d.error || 'কিছু একটা সমস্যা হয়েছে'); err.status = r.status; throw err;
    }
    return d;
}

function sessionExpired() {
    if (!currentUser) return;
    showToast('Session শেষ — আবার login করুন', 'error');
    resetToLogin();
}

// ==================== SOUND / THEME / TOAST ====================
function playSound(type = 'click') {
    if (!soundEnabled) return;
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator(), gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        const freqs = { click: 800, success: 1200, error: 300, notification: 1000, alarm: 900 };
        osc.frequency.value = freqs[type] || 800; osc.type = 'sine';
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
        osc.start(); osc.stop(ctx.currentTime + 0.15);
        setTimeout(() => ctx.close(), 400);
    } catch (e) {}
}
function toggleSound() {
    soundEnabled = !soundEnabled;
    byId('soundIcon').className = soundEnabled ? 'fa-solid fa-volume-high text-sm sound-on' : 'fa-solid fa-volume-xmark text-sm sound-off';
    showToast(soundEnabled ? '🔊 Sound ON' : '🔇 Sound OFF', 'info');
}
function toggleTheme() {
    document.body.classList.toggle('light-mode');
    const isLight = document.body.classList.contains('light-mode');
    byId('themeIcon').className = isLight ? 'fa-solid fa-sun text-sm' : 'fa-solid fa-moon text-sm';
    localStorage.setItem('ultra_theme', isLight ? 'light' : 'dark');
}
if (localStorage.getItem('ultra_theme') === 'light') {
    document.body.classList.add('light-mode');
    setTimeout(() => { const ic = byId('themeIcon'); if (ic) ic.className = 'fa-solid fa-sun text-sm'; }, 100);
}
function showToast(message, type = 'info') {
    const c = byId('toastContainer'); if (!c) return;
    const t = document.createElement('div');
    const colors = { info: 'bg-indigo-600/90 text-white', success: 'bg-emerald-600/90 text-white', error: 'bg-rose-600/90 text-white' };
    t.className = `px-4 py-2.5 rounded-xl shadow-lg backdrop-blur-md text-xs font-semibold flex items-center gap-2 transform transition-all duration-300 translate-y-[-10px] opacity-0 ${colors[type] || colors.info}`;
    t.innerHTML = `<span>${esc(message)}</span>`;
    c.appendChild(t);
    setTimeout(() => t.classList.remove('translate-y-[-10px]', 'opacity-0'), 10);
    setTimeout(() => { t.classList.add('opacity-0', 'translate-y-[-10px]'); setTimeout(() => t.remove(), 300); }, 2800);
}
function applySiteName() { if (siteSettings.siteName) document.title = siteSettings.siteName + ' · Ultimate Workspace'; }

// ==================== AUTH ====================
function showAuthError(msg) { byId('loginErrorText').textContent = msg; byId('loginError').classList.remove('hidden'); playSound('error'); }

function switchAuthTab(tab) {
    currentAuthTab = tab;
    const lt = byId('authTab-login'), st = byId('authTab-signup');
    const on = 'flex-1 py-2 rounded-lg text-xs font-semibold transition bg-indigo-600 text-white';
    const off = 'flex-1 py-2 rounded-lg text-xs font-semibold transition text-slate-400 hover:text-white';
    lt.className = tab === 'login' ? on : off; st.className = tab === 'login' ? off : on;
    byId('authSubmitText').textContent = tab === 'login' ? 'Login' : 'Create Account';
    byId('loginSubtitle').textContent = tab === 'login' ? 'Sign in to continue' : 'Create a new account';
    byId('loginError').classList.add('hidden'); byId('loginSuccess').classList.add('hidden');
}

function togglePasswordVisibility() {
    const i = byId('loginPassword'), ic = byId('eyeIcon');
    if (i.type === 'password') { i.type = 'text'; ic.className = 'fa-solid fa-eye-slash text-sm'; }
    else { i.type = 'password'; ic.className = 'fa-solid fa-eye text-sm'; }
}

async function handleAuth() {
    const username = byId('loginUsername').value.trim().toLowerCase();
    const password = byId('loginPassword').value;
    byId('loginError').classList.add('hidden'); byId('loginSuccess').classList.add('hidden');
    if (!username || !password) return showAuthError('Username এবং Password দুটোই দিন');
    const btn = byId('authSubmitBtn'); btn.disabled = true; btn.classList.add('opacity-60');
    try {
        if (currentAuthTab === 'login') {
            const d = await api('/login', 'POST', { username, password });
            currentUser = d.user; playSound('success'); loginSuccess();
        } else {
            if (!/^[a-z0-9_.]{3,20}$/.test(username)) return showAuthError('ইউজারনেম ৩-২০ অক্ষর, শুধু a-z, 0-9, _ এবং .');
            if (password.length < 6) return showAuthError('পাসওয়ার্ড কমপক্ষে ৬ অক্ষর');
            const chk = await api('/username?u=' + encodeURIComponent(username));
            if (!chk.available) return showAuthError(chk.error || 'এই ইউজারনেম নেওয়া যাবে না');
            window._pendingUser = { username, password };
            playSound('success'); openProfileSetup();
        }
    } catch (e) { showAuthError(e.message); }
    finally { btn.disabled = false; btn.classList.remove('opacity-60'); }
}

function openProfileSetup() {
    if (!window._pendingUser) return;
    byId('setupAvatarLetter').textContent = window._pendingUser.username.charAt(0).toUpperCase();
    byId('setupAvatarLetter').style.display = '';
    byId('setupDisplayName').value = window._pendingUser.username;
    byId('setupUsernameDisplay').textContent = window._pendingUser.username;
    byId('setupAvatarDisplay').style.backgroundImage = '';
    window._setupAvatar = null;
    byId('loginScreen').style.display = 'none';
    byId('profileSetupModal').classList.remove('hidden');
    setTimeout(() => byId('setupDisplayName').focus(), 200);
}

function resizeImageFile(file, size, quality, cb) {
    const reader = new FileReader();
    reader.onload = e => {
        const img = new Image();
        img.onload = () => cb(img);
        img.onerror = () => showToast('ছবি পড়া যায়নি', 'error');
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}
function squareAvatar(file, cb) {
    resizeImageFile(file, 256, 0.85, img => {
        const c = document.createElement('canvas'); c.width = 256; c.height = 256;
        const s = Math.min(img.width, img.height);
        c.getContext('2d').drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 256, 256);
        cb(c.toDataURL('image/jpeg', 0.85));
    });
}

function handleSetupAvatar(event) {
    const file = event.target.files[0]; if (!file) return;
    if (file.size > 8 * 1024 * 1024) return showToast('ছবি অনেক বড়', 'error');
    squareAvatar(file, url => {
        window._setupAvatar = url;
        const d = byId('setupAvatarDisplay'); d.style.backgroundImage = `url(${url})`; d.style.backgroundSize = 'cover';
        byId('setupAvatarLetter').style.display = 'none';
    });
}

async function completeSignup() {
    const p = window._pendingUser; if (!p) return;
    try {
        const d = await api('/signup', 'POST', {
            username: p.username, password: p.password,
            displayName: byId('setupDisplayName').value.trim() || p.username,
            bio: byId('setupBio').value.trim(), avatar: window._setupAvatar || null
        });
        currentUser = d.user;
        addNotification(`🎉 Welcome ${currentUser.displayName}!`, 'user-plus');
        playSound('success');
        byId('profileSetupModal').classList.add('hidden');
        window._pendingUser = null; window._setupAvatar = null;
        setTimeout(() => { byId('loginScreen').style.display = 'flex'; loginSuccess(); }, 300);
    } catch (e) { showToast(e.message, 'error'); }
}

function cancelSignup() {
    window._pendingUser = null; window._setupAvatar = null;
    byId('profileSetupModal').classList.add('hidden');
    byId('loginScreen').style.display = 'flex';
    byId('loginUsername').value = ''; byId('loginPassword').value = '';
}

async function loginSuccess() {
    byId('loginScreen').classList.add('login-fade-out');
    try { siteSettings = await api('/settings'); } catch (e) {}
    setTimeout(() => {
        byId('loginScreen').style.display = 'none';
        byId('mainApp').classList.remove('hidden');
        updateUserUI(); buildSidebar(); buildViews(); applySiteName(); startPolling();
    }, 500);
}

function updateUserUI() {
    if (!currentUser) return;
    const name = currentUser.displayName || currentUser.username;
    byId('currentUserHeader').textContent = name;
    byId('sidebarUserInfo').innerHTML = `<i class="fa-solid fa-user text-emerald-400 mr-1"></i>${esc(currentUser.username)}`;
    const av = byId('userAvatar');
    if (currentUser.avatar) { av.style.backgroundImage = `url(${currentUser.avatar})`; av.style.backgroundSize = 'cover'; av.textContent = ''; }
    else { av.style.backgroundImage = ''; av.textContent = name.charAt(0).toUpperCase(); }
}

function resetToLogin() {
    stopPolling();
    currentUser = null; selectedChatUser = null; usersCache = []; chatCache = []; chatsMeta = {}; totalUnread = 0; chatsLoaded = false;
    closeAdminPanel(true);
    byId('mainApp').classList.add('hidden');
    byId('loginScreen').style.display = 'flex';
    byId('loginScreen').classList.remove('login-fade-out');
    byId('loginPassword').value = ''; byId('loginUsername').value = '';
}

async function handleLogout() {
    if (!confirm('Are you sure you want to logout?')) return;
    try { await api('/logout', 'POST'); } catch (e) {}
    resetToLogin();
}

// অটো-লগইন (cookie থাকলে)
(async function autoLogin() {
    try {
        const d = await api('/me');
        currentUser = d.user; siteSettings = d.settings || siteSettings;
        byId('loginScreen').style.display = 'none';
        byId('mainApp').classList.remove('hidden');
        updateUserUI(); buildSidebar(); buildViews(); applySiteName(); startPolling();
    } catch (e) { /* login স্ক্রিনই দেখাবে */ }
})();

// ==================== POLLING (chat / online / unread) ====================
function stopPolling() { pollers.forEach(clearInterval); pollers = []; }
function startPolling() {
    stopPolling();
    api('/ping', 'POST').catch(() => {});
    refreshChats(); loadUsers();
    pollers.push(setInterval(() => api('/ping', 'POST').catch(() => {}), 25000));
    pollers.push(setInterval(refreshChats, 4000));
    pollers.push(setInterval(() => { if (isOpen('view-messages')) loadUsers(); }, 15000));
    pollers.push(setInterval(pollChat, 2500));
}

async function loadUsers() {
    try { usersCache = (await api('/users')).users; if (isOpen('view-messages')) renderUsers(); } catch (e) {}
}

async function refreshChats() {
    if (!currentUser) return;
    try {
        const d = await api('/chats');
        if (chatsLoaded) {
            for (const [uid, c] of Object.entries(d.chats)) {
                const prev = chatsMeta[uid] ? chatsMeta[uid].unread : 0;
                const viewing = selectedChatUser === uid && isOpen('view-messages') && !document.hidden;
                if (c.unread > prev && !viewing) {
                    const u = usersCache.find(x => x.id === uid);
                    const preview = c.last.type === 'voice' ? '🎤 Voice message' : c.last.type === 'image' ? '📷 Photo' : c.last.text.slice(0, 40);
                    showToast(`💬 ${u ? u.displayName : 'New message'}: ${preview}`, 'info');
                    addNotification(`💬 ${u ? u.displayName : 'কেউ'}: ${preview}`, 'message');
                    playSound('notification');
                }
            }
        }
        chatsMeta = d.chats; totalUnread = d.total; chatsLoaded = true;
        updateMessagesBadge();
        if (isOpen('view-messages')) renderUsers();
    } catch (e) {}
}

async function pollChat() {
    if (!selectedChatUser || !isOpen('view-messages')) return;
    const id = selectedChatUser;
    try {
        const d = await api(`/messages/${id}` + (document.hidden ? '' : '?markRead=1'));
        if (id !== selectedChatUser) return;
        const sig = d.messages.map(m => m.id + (m.read ? 'r' : '')).join(',');
        if (sig !== chatSig) { chatSig = sig; chatCache = d.messages; renderChatMessages(); }
    } catch (e) {}
}

// ==================== SIDEBAR MENU ====================
const MENU = [
    { id: 'dashboard', icon: 'fa-house-laptop', color: 'text-indigo-400', name: 'Dashboard' },
    { id: 'messages', icon: 'fa-comments', color: 'text-pink-400', name: 'Messages', badge: true },
    { id: 'quickeditor', icon: 'fa-code', color: 'text-emerald-400', name: 'Live Editor', tag: 'NEW' },
    { id: 'notepad', icon: 'fa-note-sticky', color: 'text-yellow-400', name: 'Notes Pad' },
    { id: 'alarm', icon: 'fa-clock', color: 'text-red-400', name: 'Alarm & Timer' },
    { id: 'pomodoro', icon: 'fa-stopwatch', color: 'text-orange-400', name: 'Pomodoro' },
    { id: 'qrcode', icon: 'fa-qrcode', color: 'text-purple-400', name: 'QR Generator' },
    { id: 'colors', icon: 'fa-palette', color: 'text-pink-400', name: 'Color Palette' },
    { id: 'gradient', icon: 'fa-fill-drip', color: 'text-fuchsia-400', name: 'Gradient Maker' },
    { id: 'converter', icon: 'fa-ruler-combined', color: 'text-cyan-400', name: 'Unit Converter' },
    { id: 'calculator', icon: 'fa-calculator', color: 'text-blue-400', name: 'Calculator' },
    { id: 'agecalculator', icon: 'fa-cake-candles', color: 'text-pink-400', name: 'Age Calc' },
    { id: 'bmi', icon: 'fa-weight-scale', color: 'text-lime-400', name: 'BMI Calc' },
    { id: 'loan', icon: 'fa-money-bill-trend-up', color: 'text-green-400', name: 'Loan Calc' },
    { id: 'expense', icon: 'fa-wallet', color: 'text-emerald-400', name: 'Expense' },
    { id: 'water', icon: 'fa-droplet', color: 'text-blue-400', name: 'Water' },
    { id: 'habits', icon: 'fa-fire', color: 'text-orange-400', name: 'Habits' },
    { id: 'calendar', icon: 'fa-calendar', color: 'text-indigo-400', name: 'Calendar' },
    { id: 'quotes', icon: 'fa-quote-left', color: 'text-amber-400', name: 'Quotes' },
    { id: 'dice', icon: 'fa-dice', color: 'text-rose-400', name: 'Dice & Random' },
    { id: 'json', icon: 'fa-file-code', color: 'text-cyan-400', name: 'JSON Format' },
    { id: 'base64', icon: 'fa-lock', color: 'text-emerald-400', name: 'Base64' },
    { id: 'uuid', icon: 'fa-fingerprint', color: 'text-purple-400', name: 'UUID Gen' },
    { id: 'markdown', icon: 'fa-markdown', color: 'text-blue-400', name: 'Markdown' },
    { id: 'piano', icon: 'fa-music', color: 'text-pink-400', name: 'Piano' },
    { id: 'drum', icon: 'fa-drum', color: 'text-amber-400', name: 'Drum Pad' },
    { id: 'metronome', icon: 'fa-wave-square', color: 'text-cyan-400', name: 'Metronome' },
    { id: 'game2048', icon: 'fa-hashtag', color: 'text-orange-400', name: '2048' },
    { id: 'sudoku', icon: 'fa-table-cells', color: 'text-blue-400', name: 'Sudoku' },
    { id: 'rps', icon: 'fa-hand-scissors', color: 'text-rose-400', name: 'Rock Paper' },
    { id: 'slot', icon: 'fa-dice-five', color: 'text-yellow-400', name: 'Slot Machine' },
    { id: 'webtools', icon: 'fa-rocket', color: 'text-pink-400', name: 'Web Tools', tag: '7' },
    { id: 'customapps', icon: 'fa-globe', color: 'text-cyan-400', name: 'Custom Apps', badgeId: 'customAppsCount' },
    { id: 'arcade', icon: 'fa-gamepad', color: 'text-amber-400', name: 'Arcade', tag: '4' },
    { id: 'videostudio', icon: 'fa-film', color: 'text-rose-400', name: 'Video Studio' },
    { id: 'designstudio', icon: 'fa-paintbrush', color: 'text-purple-400', name: 'Design Studio' },
    { id: 'developer', icon: 'fa-terminal', color: 'text-emerald-400', name: 'Developer' },
    { id: 'tracker', icon: 'fa-square-check', color: 'text-teal-400', name: 'Todo List' }
];

function buildSidebar() {
    const nav = byId('sidebarNav'); if (!nav) return;
    nav.innerHTML = MENU.map(m => `
        <button onclick="switchTab('${m.id}')" id="nav-${m.id}" class="w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/60 transition text-left text-sm font-medium ${m.id === 'dashboard' ? 'active-nav-item' : ''}">
            <div class="flex items-center gap-3"><i class="fa-solid ${m.icon} ${m.color} w-5 text-center"></i><span>${m.name}</span></div>
            ${m.tag ? `<span class="px-2 py-0.5 text-[10px] font-bold rounded-md bg-pink-500/20 text-pink-300">${m.tag}</span>` : ''}
            ${m.badgeId ? `<span id="${m.badgeId}" class="px-2 py-0.5 text-xs rounded-full bg-slate-800 text-slate-400 font-mono">${(typeof customApps !== 'undefined' ? customApps.length : 0)}</span>` : ''}
            ${m.badge ? `<span id="messagesBadge" class="hidden px-2 py-0.5 text-[10px] font-bold rounded-md bg-red-500 text-white">0</span>` : ''}
        </button>`).join('');
    updateMessagesBadge();
}

function switchTab(id) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
    const target = byId('view-' + id); if (target) target.classList.remove('hidden');
    document.querySelectorAll('aside nav button').forEach(b => b.classList.remove('active-nav-item'));
    const btn = byId('nav-' + id); if (btn) btn.classList.add('active-nav-item');
    closeSidebar(); playSound('click');
    if (id === 'messages') { renderUsers(); loadUsers(); refreshChats(); if (selectedChatUser) openChat(selectedChatUser); }
    if (id === 'calendar' && typeof renderCalendar === 'function') renderCalendar();
    if (id === 'habits' && typeof renderHabits === 'function') renderHabits();
    if (id === 'notepad') renderNotesList();
}
function toggleSidebar() { byId('sidebar').classList.toggle('-translate-x-full'); byId('mobileBackdrop').classList.toggle('hidden'); }
function closeSidebar() { byId('sidebar').classList.add('-translate-x-full'); byId('mobileBackdrop').classList.add('hidden'); }

// ==================== PROFILE MODAL ====================
function openProfileModal() {
    if (!currentUser) return;
    byId('profileDisplayName').value = currentUser.displayName || '';
    byId('profileBio').value = currentUser.bio || '';
    byId('profileNewPassword').value = '';
    delete currentUser._tempAvatar;
    byId('profileAvatarLetter').textContent = (currentUser.displayName || currentUser.username).charAt(0).toUpperCase();
    byId('profileAvatarLetter').style.display = 'block';
    const d = byId('profileAvatarDisplay');
    if (currentUser.avatar) { d.style.backgroundImage = `url(${currentUser.avatar})`; d.style.backgroundSize = 'cover'; byId('profileAvatarLetter').style.display = 'none'; }
    else d.style.backgroundImage = '';
    byId('profileModal').classList.remove('hidden');
}
function closeProfileModal() { byId('profileModal').classList.add('hidden'); }

function uploadAvatar(event) {
    const file = event.target.files[0]; if (!file) return;
    if (file.size > 8 * 1024 * 1024) return showToast('ছবি অনেক বড়', 'error');
    squareAvatar(file, url => {
        const d = byId('profileAvatarDisplay'); d.style.backgroundImage = `url(${url})`; d.style.backgroundSize = 'cover';
        byId('profileAvatarLetter').style.display = 'none';
        currentUser._tempAvatar = url;
    });
}

async function saveProfile() {
    if (!currentUser) return;
    const body = { displayName: byId('profileDisplayName').value.trim(), bio: byId('profileBio').value.trim() };
    const pw = byId('profileNewPassword').value;
    if (pw) { if (pw.length < 6) return showToast('পাসওয়ার্ড কমপক্ষে ৬ অক্ষর', 'error'); body.password = pw; }
    if (currentUser._tempAvatar) body.avatar = currentUser._tempAvatar;
    try {
        const d = await api('/me', 'PUT', body);
        currentUser = d.user; updateUserUI(); closeProfileModal(); loadUsers();
        showToast('✅ Profile updated!', 'success');
    } catch (e) { showToast(e.message, 'error'); }
}

// ==================== NOTIFICATIONS ====================
function toggleNotifications() { byId('notificationsPanel').classList.toggle('hidden'); renderNotifications(); }
function updateNotifBadge() {
    const unread = notifications.filter(n => !n.read).length, badge = byId('notifBadge'); if (!badge) return;
    if (unread > 0) { badge.textContent = unread; badge.classList.remove('hidden'); } else badge.classList.add('hidden');
}
function renderNotifications() {
    const list = byId('notificationsList'); if (!list) return;
    if (notifications.length === 0) { list.innerHTML = '<p class="text-xs text-slate-500 text-center p-4">No notifications</p>'; return; }
    list.innerHTML = notifications.slice(0, 10).map(n => `<div class="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 text-xs"><p class="text-slate-200">${esc(n.text)}</p><p class="text-[10px] text-slate-500 mt-1">${esc(n.time)}</p></div>`).join('');
    notifications.forEach(n => n.read = true); saveNotifications(); updateNotifBadge();
}
function clearNotifications() { notifications = []; saveNotifications(); renderNotifications(); }

// ==================== MESSAGES ====================
function getUnreadCount(id) { return chatsMeta[id] ? chatsMeta[id].unread : 0; }
function avatarHtml(u, cls = 'w-full h-full object-cover') {
    return u.avatar ? `<img src="${esc(u.avatar)}" class="${cls}">` : esc((u.displayName || u.username || '?').charAt(0).toUpperCase());
}

function renderUsers() {
    const list = byId('usersList'); if (!list || !currentUser) return;
    const q = (byId('searchUsers') ? byId('searchUsers').value : '').toLowerCase().trim();
    const others = usersCache.filter(u => u.id !== currentUser.id && (!q || (u.displayName || '').toLowerCase().includes(q) || u.username.includes(q)))
        .sort((a, b) => ((chatsMeta[b.id] && chatsMeta[b.id].last ? chatsMeta[b.id].last.ts : 0) - (chatsMeta[a.id] && chatsMeta[a.id].last ? chatsMeta[a.id].last.ts : 0)) || (b.isOnline - a.isOnline));
    if (others.length === 0) {
        list.innerHTML = `<div class="text-center py-12"><i class="fa-solid ${q ? 'fa-search' : 'fa-user-group'} text-5xl text-slate-700 mb-4"></i><p class="text-sm text-slate-500">${q ? 'No users found' : 'এখনো আর কোনো ইউজার নেই'}</p></div>`;
        return;
    }
    list.innerHTML = others.map(u => {
        const c = chatsMeta[u.id], last = c && c.last, unread = c ? c.unread : 0;
        let lastText = 'No messages yet';
        if (last) lastText = last.type === 'voice' ? '🎤 Voice message' : last.type === 'image' ? '📷 Photo' : (last.from === currentUser.id ? 'You: ' : '') + last.text;
        const lastTime = last ? new Date(last.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
        return `
        <div onclick="openChat('${u.id}')" class="flex items-center gap-3 p-3 rounded-2xl bg-slate-900/60 border border-slate-800 cursor-pointer hover:border-pink-500/40 hover:bg-slate-900/80 transition ${selectedChatUser === u.id ? 'border-pink-500/60 bg-pink-500/10' : ''}">
            <div class="relative w-12 h-12 rounded-full bg-gradient-to-tr from-pink-600 to-purple-600 flex items-center justify-center text-white font-bold flex-shrink-0">
                <div class="w-full h-full rounded-full overflow-hidden flex items-center justify-center">${avatarHtml(u)}</div>
                ${u.isOnline ? '<span class="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-slate-900"></span>' : ''}
            </div>
            <div class="flex-1 min-w-0">
                <div class="flex items-center justify-between gap-2"><p class="text-sm font-semibold text-white truncate">${esc(u.displayName || u.username)} ${u.isAdmin ? '👑' : ''}</p>${lastTime ? `<span class="text-[10px] text-slate-500 flex-shrink-0">${lastTime}</span>` : ''}</div>
                <div class="flex items-center justify-between gap-2 mt-0.5"><p class="text-xs text-slate-400 truncate">${esc(lastText)}</p>${unread > 0 ? `<span class="px-2 py-0.5 text-[10px] font-bold rounded-full bg-red-500 text-white flex-shrink-0">${unread}</span>` : ''}</div>
            </div>
        </div>`;
    }).join('');
}
function filterUsers() { renderUsers(); }

async function openChat(userId) {
    const user = usersCache.find(u => u.id === userId); if (!user) return;
    const changed = selectedChatUser !== userId;
    selectedChatUser = userId;
    if (changed) { chatCache = []; chatSig = ''; }
    const av = byId('chatAvatar');
    if (user.avatar) { av.style.backgroundImage = `url(${user.avatar})`; av.style.backgroundSize = 'cover'; av.textContent = ''; }
    else { av.style.backgroundImage = ''; av.textContent = (user.displayName || user.username).charAt(0).toUpperCase(); }
    byId('chatName').textContent = (user.displayName || user.username) + (user.isAdmin ? ' 👑' : '');
    byId('chatStatus').innerHTML = user.isOnline ? '<span class="text-emerald-400">🟢 Online</span>'
        : `<span class="text-slate-500">${user.lastActive ? 'Last seen: ' + esc(new Date(user.lastActive).toLocaleString()) : 'Offline'}</span>`;
    const lv = byId('messagesListView'), cv = byId('chatView');
    if (window.innerWidth < 768) lv.classList.add('hidden-mobile');
    cv.classList.remove('hidden');
    if (changed) renderChatMessages();
    await pollChat(); refreshChats();
    if (changed) setTimeout(() => { const i = byId('messageInput'); if (i) i.focus(); }, 100);
    renderUsers();
}

function closeChat() {
    selectedChatUser = null;
    byId('messagesListView').classList.remove('hidden-mobile');
    byId('chatView').classList.add('hidden');
    renderUsers();
}

let _lastRenderedChat = null;
function renderChatMessages() {
    const box = byId('chatMessages'); if (!box || !selectedChatUser || !currentUser) return;
    const msgs = chatCache;
    const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 120 || _lastRenderedChat !== selectedChatUser;
    _lastRenderedChat = selectedChatUser;
    if (msgs.length === 0) {
        box.innerHTML = `<div class="flex items-center justify-center h-full"><div class="text-center"><i class="fa-solid fa-comments text-5xl text-slate-700 mb-4"></i><p class="text-sm text-slate-500">No messages yet</p><p class="text-xs text-slate-600 mt-1">Say hi! 👋</p></div></div>`;
        return;
    }
    let lastDate = '';
    box.innerHTML = msgs.map((m, idx) => {
        const isMe = m.from === currentUser.id;
        const time = new Date(m.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const date = new Date(m.ts).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' });
        let divider = '';
        if (date !== lastDate) { divider = `<div class="flex justify-center my-3"><span class="px-3 py-1 rounded-full bg-slate-800/80 text-[10px] text-slate-400 font-medium">${date}</span></div>`; lastDate = date; }
        const showAvatar = !isMe && (idx === msgs.length - 1 || msgs[idx + 1].from !== m.from);
        const user = usersCache.find(u => u.id === m.from) || {};
        let content;
        if (m.type === 'voice') content = `<audio controls preload="none" src="/api/media/${m.id}" class="max-w-full h-10"></audio>`;
        else if (m.type === 'image') content = `<img src="/api/media/${m.id}" class="max-w-full rounded-lg cursor-pointer" onclick="window.open('/api/media/${m.id}')" style="max-height:250px">`;
        else content = esc(m.text);
        return `${divider}
        <div class="flex ${isMe ? 'justify-end' : 'justify-start'} gap-2 items-end">
            ${!isMe && showAvatar ? `<div class="w-7 h-7 rounded-full bg-gradient-to-tr from-pink-600 to-purple-600 flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0 overflow-hidden">${avatarHtml(user)}</div>` : (!isMe ? '<div class="w-7 flex-shrink-0"></div>' : '')}
            <div class="msg-bubble ${isMe ? 'me' : 'other'}">${content}<div class="msg-time">${time} ${isMe ? (m.read ? '✓✓' : '✓') : ''}</div></div>
        </div>`;
    }).join('');
    if (nearBottom) setTimeout(() => box.scrollTop = box.scrollHeight, 30);
}

async function postMessage(body) {
    try {
        const d = await api('/messages', 'POST', { to: selectedChatUser, ...body });
        chatCache.push(d.message); chatSig = chatCache.map(m => m.id + (m.read ? 'r' : '')).join(',');
        renderChatMessages(); refreshChats(); return true;
    } catch (e) { showToast(e.message, 'error'); return false; }
}

async function sendMessage() {
    const input = byId('messageInput'), text = input.value.trim();
    if (!text || !selectedChatUser || !currentUser) return;
    input.value = ''; input.style.height = 'auto';
    const ok = await postMessage({ type: 'text', text });
    if (!ok) input.value = text; else playSound('click');
}

async function clearChatWithUser() {
    if (!selectedChatUser || !confirm('Delete all messages with this user?')) return;
    try { await api('/messages/' + selectedChatUser, 'DELETE'); chatCache = []; chatSig = ''; renderChatMessages(); refreshChats(); showToast('Chat cleared', 'info'); }
    catch (e) { showToast(e.message, 'error'); }
}

function updateMessagesBadge() {
    const badge = byId('messagesBadge'); if (!badge) return;
    if (totalUnread > 0) { badge.textContent = totalUnread; badge.classList.remove('hidden'); } else badge.classList.add('hidden');
}

// ==================== VOICE RECORDING ====================
function startRecording() {
    if (!selectedChatUser) return;
    if (!navigator.mediaDevices || !window.MediaRecorder) return showToast('Recording not supported', 'error');
    navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
        audioChunks = []; recordingCancelled = false;
        mediaRecorder = new MediaRecorder(stream);
        mediaRecorder.ondataavailable = e => { if (e.data.size > 0) audioChunks.push(e.data); };
        mediaRecorder.onstop = () => {
            stream.getTracks().forEach(t => t.stop());
            if (recordingCancelled) { recordingCancelled = false; return; }
            const blob = new Blob(audioChunks, { type: mediaRecorder.mimeType || 'audio/webm' });
            if (blob.size > 2400000) return showToast('ভয়েস অনেক বড় — ছোট করে রেকর্ড করুন', 'error');
            const reader = new FileReader();
            reader.onload = async () => { if (await postMessage({ type: 'voice', data: reader.result })) showToast('🎤 Voice message sent', 'success'); };
            reader.readAsDataURL(blob);
        };
        mediaRecorder.start(); recordingStartTime = Date.now();
        byId('recordingBar').classList.remove('hidden'); byId('recordingTime').textContent = '0:00';
        recordingTimer = setInterval(() => {
            const s = Math.floor((Date.now() - recordingStartTime) / 1000);
            byId('recordingTime').textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
            if (s >= 90) stopRecording();
        }, 500);
    }).catch(() => showToast('Microphone access denied', 'error'));
}
function stopRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
    clearInterval(recordingTimer); byId('recordingBar').classList.add('hidden');
}
function cancelRecording() {
    recordingCancelled = true;
    if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
    clearInterval(recordingTimer); byId('recordingBar').classList.add('hidden');
}

// ==================== PHOTO UPLOAD (compress করে) ====================
function handleFileUpload(event) {
    const file = event.target.files[0]; event.target.value = '';
    if (!file || !selectedChatUser || !currentUser) return;
    if (!file.type.startsWith('image/')) return showToast('শুধু ছবি পাঠানো যাবে', 'error');
    resizeImageFile(file, 1280, 0.8, async img => {
        const max = 1280, r = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas'); c.width = Math.round(img.width * r); c.height = Math.round(img.height * r);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        if (await postMessage({ type: 'image', data: c.toDataURL('image/jpeg', 0.8) })) showToast('📷 Photo sent', 'success');
    });
}

// ==================== EMOJI PICKER ====================
const EMOJIS = ['😀','😁','😂','🤣','😊','😍','🥰','😘','😎','🤩','🥳','😏','😢','😭','😡','🤯','😱','🤔','🙄','😴','🤝','🙏','👏','💪','👍','👎','✌️','❤️','💔','💯','🔥','✨','🎉','🎁','🌹','🍕','⚽','🎵','⭐','🌈'];
function toggleEmojiPicker() {
    const p = byId('emojiPicker'); if (!p) return;
    p.classList.toggle('hidden');
    if (!p.classList.contains('hidden') && !p.dataset.init) {
        byId('emojiGrid').innerHTML = EMOJIS.map(e => `<button onclick="addEmoji('${e}')" class="text-2xl hover:scale-125 transition">${e}</button>`).join('');
        p.dataset.init = '1';
    }
}
function addEmoji(e) { const i = byId('messageInput'); i.value += e; i.focus(); }

// ==================== ADMIN PANEL (সার্ভার যাচাই করে) ====================
function promptAdminPassword() {
    byId('adminPasswordModal').classList.remove('hidden');
    byId('adminPasswordInput').value = '';
    byId('adminPasswordError').classList.add('hidden');
    setTimeout(() => byId('adminPasswordInput').focus(), 100);
}
function closeAdminPasswordModal() { byId('adminPasswordModal').classList.add('hidden'); }

async function verifyAdminPassword() {
    const pw = byId('adminPasswordInput').value; if (!pw) return;
    try {
        await api('/admin/login', 'POST', { password: pw });
        closeAdminPasswordModal(); playSound('success'); openAdminPanel();
    } catch (e) {
        const el = byId('adminPasswordError'); el.textContent = e.message; el.classList.remove('hidden');
        byId('adminPasswordInput').value = ''; playSound('error');
    }
}
document.addEventListener('keypress', e => {
    if (e.key === 'Enter' && e.target.id === 'adminPasswordInput') verifyAdminPassword();
    if (e.key === 'Enter' && e.target.id === 'loginPassword') handleAuth();
});

async function openAdminPanel() { byId('adminPanel').classList.remove('hidden'); await refreshAdmin(); }
function closeAdminPanel(silent) {
    byId('adminPanel').classList.add('hidden'); adminData = null;
    if (!silent) api('/admin/logout', 'POST').catch(() => {});
}

async function refreshAdmin() {
    try { adminData = await api('/admin/overview'); renderAdminPanel(); }
    catch (e) { showToast(e.message, 'error'); closeAdminPanel(true); }
}

function renderAdminPanel() {
    if (!adminData) return;
    const { stats, settings, logs, users } = adminData;
    const online = users.filter(u => u.isOnline);
    byId('adminPanelContent').innerHTML = `
        <div class="glass-card rounded-2xl p-6 border-2 border-pink-500/40 mb-6 bg-gradient-to-r from-pink-950/40 via-purple-950/40 to-slate-900/60">
            <div class="flex items-center justify-between flex-wrap gap-4">
                <div class="flex items-center gap-4"><div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-pink-600 to-purple-600 flex items-center justify-center shadow-lg admin-pulse"><i class="fa-solid fa-crown text-white text-2xl"></i></div>
                <div><h2 class="font-heading font-extrabold text-2xl text-white">👑 Admin Panel</h2><p class="text-xs text-pink-300">${esc(settings.siteName)}</p></div></div>
                <div class="flex gap-2"><button onclick="refreshAdmin()" class="px-3 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-semibold"><i class="fa-solid fa-rotate"></i> Refresh</button>
                <button onclick="closeAdminPanel()" class="px-3 py-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 text-xs font-semibold"><i class="fa-solid fa-xmark"></i> Close</button></div>
            </div>
        </div>
        <div class="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
            <div class="glass-card p-5 rounded-2xl border border-indigo-500/30"><i class="fa-solid fa-users text-indigo-400 text-2xl mb-2"></i><p class="text-3xl font-heading font-extrabold text-white">${stats.total}</p><p class="text-xs text-slate-400">Total Users</p></div>
            <div class="glass-card p-5 rounded-2xl border border-emerald-500/30"><i class="fa-solid fa-circle text-emerald-400 text-2xl live-pulse mb-2"></i><p class="text-3xl font-heading font-extrabold text-white">${stats.online}</p><p class="text-xs text-slate-400">Online</p></div>
            <div class="glass-card p-5 rounded-2xl border border-slate-500/30"><i class="fa-solid fa-circle text-slate-400 text-2xl mb-2"></i><p class="text-3xl font-heading font-extrabold text-white">${stats.total - stats.online}</p><p class="text-xs text-slate-400">Offline</p></div>
            <div class="glass-card p-5 rounded-2xl border border-amber-500/30"><i class="fa-solid fa-ban text-amber-400 text-2xl mb-2"></i><p class="text-3xl font-heading font-extrabold text-white">${stats.banned}</p><p class="text-xs text-slate-400">Banned</p></div>
            <div class="glass-card p-5 rounded-2xl border border-pink-500/30"><i class="fa-solid fa-comments text-pink-400 text-2xl mb-2"></i><p class="text-3xl font-heading font-extrabold text-white">${stats.messages}</p><p class="text-xs text-slate-400">Messages</p></div>
        </div>
        <div class="glass-card rounded-2xl border border-emerald-500/30 mb-6 overflow-hidden">
            <div class="px-6 py-4 border-b border-slate-700/60 flex items-center gap-2 bg-emerald-950/20"><span class="w-2 h-2 rounded-full bg-emerald-400 live-pulse"></span><h3 class="font-heading font-bold text-lg text-white">🟢 Online Users</h3></div>
            <div class="p-4 space-y-2">${online.map(u => `
                <div class="flex items-center justify-between p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                    <div class="flex items-center gap-3"><div class="w-9 h-9 rounded-full bg-gradient-to-tr from-emerald-600 to-cyan-600 flex items-center justify-center text-white text-xs font-bold overflow-hidden">${avatarHtml(u)}</div>
                    <div><p class="text-sm text-white font-medium">${esc(u.displayName || u.username)} ${u.isAdmin ? '👑' : ''}</p><p class="text-[10px] text-slate-400">@${esc(u.username)}</p></div></div>
                    <span class="px-2 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">🟢 ONLINE</span>
                </div>`).join('') || '<p class="text-xs text-slate-500 text-center py-3">কেউ online নেই</p>'}</div>
        </div>
        <div class="glass-card rounded-2xl border border-slate-700/60 overflow-hidden mb-6">
            <div class="px-6 py-4 border-b border-slate-700/60 flex items-center justify-between flex-wrap gap-3">
                <h3 class="font-heading font-bold text-lg text-white">User Management</h3>
                <input type="text" id="searchUser" oninput="renderAdminUsersTable()" placeholder="Search..." class="bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 w-48">
            </div>
            <div class="overflow-x-auto"><table class="w-full text-sm">
                <thead class="bg-slate-900/60"><tr class="text-left text-xs text-slate-400 uppercase"><th class="px-6 py-3">User</th><th class="px-6 py-3">Status</th><th class="px-6 py-3">Joined</th><th class="px-6 py-3">Visits</th><th class="px-6 py-3">Actions</th></tr></thead>
                <tbody id="adminUsersBody"></tbody></table></div>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
            <div class="glass-card rounded-2xl border border-slate-700/60 p-6"><h3 class="font-bold text-lg text-white mb-4">Site Settings</h3>
                <input type="text" id="siteNameInput" value="${esc(settings.siteName)}" maxlength="40" placeholder="Site Name" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 mb-3">
                <button onclick="saveSiteSettings()" class="w-full py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold"><i class="fa-solid fa-save mr-1"></i> Save</button></div>
            <div class="glass-card rounded-2xl border border-slate-700/60 p-6"><h3 class="font-bold text-lg text-white mb-4">Announcement</h3>
                <textarea id="announcementInput" rows="3" maxlength="500" placeholder="Type announcement (খালি রেখে Post করলে মুছে যাবে)..." class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 resize-none mb-3">${esc(settings.announcement)}</textarea>
                <button onclick="postAnnouncement()" class="w-full py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold"><i class="fa-solid fa-paper-plane mr-1"></i> Post</button></div>
        </div>
        <div class="glass-card rounded-2xl border border-slate-700/60 p-6">
            <div class="flex items-center justify-between mb-4"><h3 class="font-bold text-lg text-white">Activity Log</h3><button onclick="clearLogs()" class="text-xs text-red-400 px-3 py-1 rounded-lg bg-red-500/10">Clear</button></div>
            <div class="space-y-2 max-h-80 overflow-y-auto">${logs.slice(0, 30).map(l => `<div class="flex items-start gap-3 p-2.5 rounded-lg bg-slate-900/40 border border-slate-800"><i class="fa-solid fa-info-circle text-indigo-400 text-xs mt-0.5"></i><div class="flex-1"><p class="text-xs text-slate-200">${esc(l.action)}</p><p class="text-[10px] text-slate-500 mt-0.5">${esc(new Date(l.ts).toLocaleString())} · @${esc(l.user || 'guest')}</p></div></div>`).join('') || '<p class="text-xs text-slate-500 text-center py-3">No activity</p>'}</div>
        </div>`;
    renderAdminUsersTable();
}

function renderAdminUsersTable() {
    const body = byId('adminUsersBody'); if (!body || !adminData) return;
    const q = (byId('searchUser') ? byId('searchUser').value : '').toLowerCase();
    body.innerHTML = adminData.users.filter(u => !q || u.username.includes(q) || (u.displayName || '').toLowerCase().includes(q)).map(u => `
        <tr class="border-b border-slate-800">
            <td class="px-6 py-3"><div class="flex items-center gap-3"><div class="w-9 h-9 rounded-lg ${u.isAdmin ? 'bg-gradient-to-tr from-pink-600 to-purple-600' : 'bg-slate-700'} flex items-center justify-center text-white text-xs font-bold overflow-hidden">${u.avatar ? avatarHtml(u) : (u.isAdmin ? '👑' : esc(u.username.charAt(0).toUpperCase()))}</div><div><p class="text-sm text-white">${esc(u.displayName || u.username)}</p><p class="text-[10px] text-slate-500">@${esc(u.username)}</p></div></div></td>
            <td class="px-6 py-3"><span class="px-2.5 py-1 rounded-full text-[10px] font-bold ${u.status === 'active' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'}">${u.status === 'active' ? '● Active' : '● Banned'}</span></td>
            <td class="px-6 py-3 text-xs text-slate-400">${esc(u.joined)}</td>
            <td class="px-6 py-3 text-xs text-slate-400">${u.visits}</td>
            <td class="px-6 py-3">${!u.isAdmin ? `<div class="flex gap-2"><button onclick="toggleBan('${u.id}')" class="px-3 py-1 rounded-lg ${u.status === 'active' ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'} text-[10px] font-semibold">${u.status === 'active' ? 'Ban' : 'Unban'}</button><button onclick="deleteUser('${u.id}')" class="px-3 py-1 rounded-lg bg-red-500/20 text-red-300 text-[10px]"><i class="fa-solid fa-trash"></i></button></div>` : '<span class="text-[10px] text-pink-300">👑 Admin</span>'}</td>
        </tr>`).join('');
}

async function toggleBan(id) {
    try { const d = await api(`/admin/users/${id}/ban`, 'POST'); showToast(d.status === 'banned' ? 'ইউজার ব্যান হয়েছে' : 'ইউজার আনব্যান হয়েছে', d.status === 'banned' ? 'error' : 'success'); await refreshAdmin(); }
    catch (e) { showToast(e.message, 'error'); }
}
async function deleteUser(id) {
    const u = adminData && adminData.users.find(x => x.id === id);
    if (!u || !confirm(`Delete "${u.username}"? তার সব মেসেজও মুছে যাবে।`)) return;
    try { await api('/admin/users/' + id, 'DELETE'); await refreshAdmin(); loadUsers(); } catch (e) { showToast(e.message, 'error'); }
}
async function saveSiteSettings() {
    try { siteSettings = await api('/admin/settings', 'PUT', { siteName: byId('siteNameInput').value }); applySiteName(); showToast('✅ Settings saved!', 'success'); } catch (e) { showToast(e.message, 'error'); }
}
async function postAnnouncement() {
    try {
        siteSettings = await api('/admin/settings', 'PUT', { announcement: byId('announcementInput').value });
        const ad = byId('announcementDisplay');
        if (ad) { ad.classList.toggle('hidden', !siteSettings.announcement); byId('announcementText').textContent = siteSettings.announcement; }
        showToast('✅ Posted!', 'success');
    } catch (e) { showToast(e.message, 'error'); }
}
async function clearLogs() {
    if (!confirm('Clear logs?')) return;
    try { await api('/admin/logs', 'DELETE'); await refreshAdmin(); } catch (e) { showToast(e.message, 'error'); }
}

// ==================== NOTES (এই ডিভাইসে সেভ হয়) ====================
function renderNotesList() {
    const list = byId('notesList'); if (!list) return;
    if (notes.length === 0) { list.innerHTML = '<p class="text-xs text-slate-500 text-center p-3">No notes yet</p>'; return; }
    list.innerHTML = notes.map(n => `
        <div onclick="loadNote('${n.id}')" class="p-3 rounded-xl bg-slate-900/60 border border-slate-800 cursor-pointer hover:border-yellow-500/40 transition ${n.id === currentNoteId ? 'border-yellow-500/60 bg-yellow-500/10' : ''}">
            <p class="text-xs font-semibold text-white truncate">${esc(n.title || 'Untitled')}</p>
            <p class="text-[10px] text-slate-500 mt-1">${new Date(n.updated).toLocaleDateString()}</p>
        </div>`).join('');
}
function newNote() {
    const note = { id: Date.now().toString(), title: '', content: '', updated: new Date().toISOString() };
    notes.unshift(note); saveNotes(); currentNoteId = note.id; renderNotesList();
    byId('noteTitle').value = ''; byId('noteContent').value = ''; byId('noteTitle').focus();
}
function loadNote(id) {
    const note = notes.find(n => n.id === id); if (!note) return;
    currentNoteId = id; byId('noteTitle').value = note.title; byId('noteContent').value = note.content; renderNotesList();
}
function autoSaveNote() {
    if (!currentNoteId) return;
    const note = notes.find(n => n.id === currentNoteId);
    if (note) {
        note.title = byId('noteTitle') ? byId('noteTitle').value : ''; note.content = byId('noteContent') ? byId('noteContent').value : '';
        note.updated = new Date().toISOString(); saveNotes(); renderNotesList();
        const st = byId('noteSavedStatus'); if (st) st.textContent = '✅ Saved ' + new Date().toLocaleTimeString();
    }
}
function deleteCurrentNote() {
    if (!currentNoteId || !confirm('Delete this note?')) return;
    notes = notes.filter(n => n.id !== currentNoteId); saveNotes(); currentNoteId = null;
    byId('noteTitle').value = ''; byId('noteContent').value = ''; renderNotesList();
}

// ==================== CLOCK & ALARM ====================
function updateClock() {
    const now = new Date();
    const clockEl = byId('liveClock');
    if (clockEl) { clockEl.textContent = now.toLocaleTimeString('en-US', { hour12: false }); byId('liveDate').textContent = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); }
    const cur = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
    alarms.forEach(a => {
        if (a.time !== cur) a.triggered = false;
        else if (a.active && !a.triggered) { a.triggered = true; triggerAlarm(a); }
    });
}
setInterval(updateClock, 1000);

function setAlarm() {
    const time = byId('alarmTime').value, label = byId('alarmLabel').value || 'Alarm';
    if (!time) return showToast('সময় দিন', 'error');
    alarms.push({ id: Date.now().toString(), time, label, active: true, triggered: false });
    saveAlarms(); renderAlarms(); byId('alarmTime').value = ''; byId('alarmLabel').value = '';
    showToast('⏰ Alarm set for ' + time, 'success');
}
function renderAlarms() {
    const list = byId('alarmsList'); if (!list) return;
    if (alarms.length === 0) { list.innerHTML = '<p class="text-[10px] text-slate-500 text-center">No alarms</p>'; return; }
    list.innerHTML = alarms.map(a => `<div class="flex items-center justify-between p-2 rounded-lg bg-slate-900/60 border border-slate-800"><div><p class="text-xs font-bold text-white">${esc(a.time)}</p><p class="text-[10px] text-slate-400">${esc(a.label)}</p></div><button onclick="deleteAlarm('${a.id}')" class="text-red-400 text-xs"><i class="fa-solid fa-trash"></i></button></div>`).join('');
}
function deleteAlarm(id) { alarms = alarms.filter(a => a.id !== id); saveAlarms(); renderAlarms(); }
function triggerAlarm(alarm) {
    playSound('alarm'); setTimeout(() => playSound('alarm'), 300); setTimeout(() => playSound('alarm'), 600);
    showToast(`⏰ ${alarm.label} (${alarm.time})`, 'success');
    addNotification(`⏰ Alarm: ${alarm.label}`, 'clock');
    setTimeout(() => alert(`⏰ ALARM: ${alarm.label}\nTime: ${alarm.time}`), 50);
}

// ==================== TIMER ====================
function startTimer() {
    const min = parseInt(byId('timerMinutes').value) || 0, sec = parseInt(byId('timerSeconds').value) || 0;
    if (timerInterval) return;
    if (timerSecondsLeft <= 0) {
        if (min === 0 && sec === 0) return showToast('সময় দিন', 'error');
        timerTotal = min * 60 + sec; timerSecondsLeft = timerTotal;
    }
    timerInterval = setInterval(() => {
        timerSecondsLeft--; updateTimerDisplay();
        if (timerSecondsLeft <= 0) {
            clearInterval(timerInterval); timerInterval = null; timerSecondsLeft = 0;
            playSound('alarm'); setTimeout(() => playSound('alarm'), 300);
            showToast('⏰ Timer done!', 'success'); setTimeout(() => alert('⏰ Timer Complete!'), 50);
        }
    }, 1000);
}
function pauseTimer() { clearInterval(timerInterval); timerInterval = null; }
function resetTimer() {
    clearInterval(timerInterval); timerInterval = null; timerSecondsLeft = 0; timerTotal = 0; updateTimerDisplay();
    const m = byId('timerMinutes'); if (m) m.value = ''; const s = byId('timerSeconds'); if (s) s.value = '';
}
function updateTimerDisplay() {
    const el = byId('timerDisplay');
    if (el) el.textContent = `${Math.floor(timerSecondsLeft / 60).toString().padStart(2, '0')}:${(timerSecondsLeft % 60).toString().padStart(2, '0')}`;
    const c = byId('timerCircle');
    if (c) c.style.strokeDashoffset = timerTotal > 0 ? 283 * (1 - timerSecondsLeft / timerTotal) : 0;
}

// ==================== STOPWATCH ====================
function fmtStopwatch() {
    const ms = Math.floor((stopwatchTime % 1000) / 10), s = Math.floor(stopwatchTime / 1000) % 60, m = Math.floor(stopwatchTime / 60000);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}:${ms.toString().padStart(2, '0')}`;
}
function startStopwatch() {
    if (stopwatchInterval) return;
    const base = Date.now() - stopwatchTime;
    stopwatchInterval = setInterval(() => { stopwatchTime = Date.now() - base; const el = byId('stopwatchDisplay'); if (el) el.textContent = fmtStopwatch(); }, 30);
}
function lapStopwatch() {
    if (stopwatchTime === 0) return;
    const lapsList = byId('lapsList'); if (!lapsList) return;
    const lap = document.createElement('div'); lap.className = 'p-2 rounded bg-slate-900/60 text-xs flex justify-between';
    lap.innerHTML = `<span class="text-slate-400">Lap ${lapsList.children.length + 1}</span><span class="text-cyan-300 font-mono">${fmtStopwatch()}</span>`;
    lapsList.prepend(lap);
}
function resetStopwatch() {
    clearInterval(stopwatchInterval); stopwatchInterval = null; stopwatchTime = 0;
    const el = byId('stopwatchDisplay'); if (el) el.textContent = '00:00:00';
    const l = byId('lapsList'); if (l) l.innerHTML = '';
}

console.log('%c📦 PART 2 (server) Loaded', 'color:#ec4899;font-size:14px;font-weight:bold');
