// ==================== PWA: Install App + Service Worker ====================
(function () {
  // --- head tags (manifest, theme, iOS) ---
  const head = document.head;
  const add = (tag, attrs) => { const el = document.createElement(tag); Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v)); head.appendChild(el); };
  if (!document.querySelector('link[rel="manifest"]')) add('link', { rel: 'manifest', href: 'manifest.json' });
  if (!document.querySelector('meta[name="theme-color"]')) add('meta', { name: 'theme-color', content: '#6366f1' });
  add('meta', { name: 'apple-mobile-web-app-capable', content: 'yes' });
  add('meta', { name: 'apple-mobile-web-app-status-bar-style', content: 'black-translucent' });
  add('meta', { name: 'apple-mobile-web-app-title', content: 'Ultra Suite' });
  add('link', { rel: 'apple-touch-icon', href: 'icons/apple-touch-icon.png' });

  // --- helpers ---
  const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const toast = (m, t) => (typeof showToast === 'function' ? showToast(m, t || 'info') : console.log(m));
  let deferredPrompt = null;

  // --- Service Worker ---
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').then(reg => {
        reg.addEventListener('updatefound', () => {
          const nw = reg.installing;
          if (!nw) return;
          nw.addEventListener('statechange', () => {
            if (nw.state === 'installed' && navigator.serviceWorker.controller) {
              toast('🔄 নতুন ভার্সন পাওয়া গেছে — রিলোড করুন', 'info');
              showUpdateBar();
            }
          });
        });
      }).catch(err => console.warn('SW failed', err));
    });
  }

  function showUpdateBar() {
    if (document.getElementById('pwaUpdateBar')) return;
    const b = document.createElement('div');
    b.id = 'pwaUpdateBar';
    b.style.cssText = 'position:fixed;left:12px;right:12px;bottom:12px;z-index:300;background:#1e1b4b;border:1px solid #6366f1;color:#fff;border-radius:14px;padding:12px 14px;display:flex;align-items:center;justify-content:space-between;gap:10px;font:600 12px Inter,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.5)';
    b.innerHTML = '<span>🔄 নতুন আপডেট এসেছে</span><button style="background:#6366f1;color:#fff;border:0;border-radius:10px;padding:8px 14px;font-weight:700;cursor:pointer">Reload</button>';
    b.querySelector('button').onclick = () => location.reload();
    document.body.appendChild(b);
  }

  // --- Install button ---
  function buildInstallUI() {
    if (isStandalone() || document.getElementById('installAppBtn')) return;
    const btn = document.createElement('button');
    btn.id = 'installAppBtn';
    btn.style.cssText = 'position:fixed;right:14px;bottom:14px;z-index:90;display:none;align-items:center;gap:8px;background:linear-gradient(90deg,#6366f1,#a855f7);color:#fff;border:0;border-radius:999px;padding:11px 16px;font:700 12px Inter,sans-serif;cursor:pointer;box-shadow:0 8px 24px rgba(99,102,241,.5)';
    btn.innerHTML = '<span>📲 Install App</span><span id="installClose" style="opacity:.7;font-size:14px;padding-left:4px">✕</span>';
    btn.addEventListener('click', e => {
      if (e.target.id === 'installClose') { btn.style.display = 'none'; sessionStorage.setItem('pwa_hide', '1'); return; }
      installApp();
    });
    document.body.appendChild(btn);
    if (!sessionStorage.getItem('pwa_hide')) btn.style.display = 'flex';
  }

  function installApp() {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then(r => {
        if (r.outcome === 'accepted') toast('✅ Installing...', 'success');
        deferredPrompt = null;
        const b = document.getElementById('installAppBtn'); if (b && r.outcome === 'accepted') b.style.display = 'none';
      });
    } else {
      showHowTo();
    }
  }

  function showHowTo() {
    const old = document.getElementById('installHowTo'); if (old) old.remove();
    const m = document.createElement('div');
    m.id = 'installHowTo';
    m.style.cssText = 'position:fixed;inset:0;z-index:400;background:rgba(0,0,0,.75);display:flex;align-items:center;justify-content:center;padding:16px';
    const steps = isIOS
      ? '<li>Safari এর নিচে <b>Share</b> (⬆️) আইকনে ট্যাপ করুন</li><li>নিচে স্ক্রল করে <b>Add to Home Screen</b> চাপুন</li><li><b>Add</b> চাপলেই হোম স্ক্রিনে app আইকন আসবে</li>'
      : '<li>ব্রাউজারের মেনু (⋮) খুলুন</li><li><b>Install app</b> বা <b>Add to Home screen</b> চাপুন</li><li>Confirm করুন — হোম স্ক্রিন/ডেস্কটপে আইকন আসবে</li>';
    m.innerHTML = `<div style="background:#0f172a;border:1px solid #6366f1;border-radius:18px;max-width:380px;width:100%;padding:20px;color:#e2e8f0;font:14px Inter,sans-serif">
      <h3 style="font:800 18px Outfit,sans-serif;color:#fff;margin:0 0 10px">📲 App Install করুন</h3>
      <ol style="padding-left:18px;line-height:1.8;margin:0 0 14px">${steps}</ol>
      <button style="width:100%;background:#6366f1;color:#fff;border:0;border-radius:12px;padding:10px;font-weight:700;cursor:pointer">ঠিক আছে</button></div>`;
    m.querySelector('button').onclick = () => m.remove();
    m.addEventListener('click', e => { if (e.target === m) m.remove(); });
    document.body.appendChild(m);
  }

  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    buildInstallUI();
    const b = document.getElementById('installAppBtn');
    if (b && !sessionStorage.getItem('pwa_hide')) b.style.display = 'flex';
  });

  window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    const b = document.getElementById('installAppBtn'); if (b) b.remove();
    toast('🎉 App install হয়েছে!', 'success');
  });

  // iOS ও অন্য ব্রাউজার (যেগুলো prompt event দেয় না) — বাটন দেখাও যাতে গাইড খোলে
  window.addEventListener('load', () => { setTimeout(() => { if (!isStandalone()) buildInstallUI(); }, 1500); });

  // কনসোল/অন্য জায়গা থেকে ডাকার জন্য
  window.installUltraSuite = installApp;
})();
